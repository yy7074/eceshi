#!/usr/bin/env python3
"""测试修复后的API端点"""

import requests
import json
from typing import Dict, Any

BASE_URL = "http://localhost:3000/api/v1"

# 测试用户凭证（需要先创建测试用户）
TEST_USER = {
    "username": "test_user",
    "password": "test123456"
}

class APITester:
    def __init__(self):
        self.token = None
        self.results = []
    
    def login(self):
        """登录获取token"""
        try:
            response = requests.post(
                f"{BASE_URL}/auth/login",
                json=TEST_USER,
                timeout=10
            )
            if response.status_code == 200:
                data = response.json()
                self.token = data.get("access_token")
                print("✅ 登录成功")
                return True
            else:
                print(f"❌ 登录失败: {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ 登录异常: {str(e)}")
            return False
    
    def get_headers(self):
        """获取请求头"""
        if self.token:
            return {"Authorization": f"Bearer {self.token}"}
        return {}
    
    def test_api(self, name: str, method: str, endpoint: str, **kwargs):
        """测试API端点"""
        url = f"{BASE_URL}{endpoint}"
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=self.get_headers(), timeout=10, **kwargs)
            elif method.upper() == "POST":
                response = requests.post(url, headers=self.get_headers(), timeout=10, **kwargs)
            else:
                print(f"❌ {name}: 不支持的方法 {method}")
                return False
            
            status = response.status_code
            if 200 <= status < 300:
                print(f"✅ {name}: {status}")
                self.results.append({"name": name, "status": "success", "code": status})
                return True
            elif status == 401:
                print(f"⚠️  {name}: {status} (需要登录)")
                self.results.append({"name": name, "status": "auth_required", "code": status})
                return False
            else:
                print(f"❌ {name}: {status}")
                try:
                    error_data = response.json()
                    print(f"   错误信息: {error_data.get('detail', 'Unknown error')}")
                except:
                    pass
                self.results.append({"name": name, "status": "failed", "code": status})
                return False
        except requests.exceptions.Timeout:
            print(f"⏱️  {name}: 超时")
            self.results.append({"name": name, "status": "timeout", "code": None})
            return False
        except Exception as e:
            print(f"❌ {name}: 异常 - {str(e)}")
            self.results.append({"name": name, "status": "error", "code": None, "error": str(e)})
            return False
    
    def print_summary(self):
        """打印测试摘要"""
        print("\n" + "="*60)
        print("测试摘要")
        print("="*60)
        
        success = sum(1 for r in self.results if r["status"] == "success")
        auth_required = sum(1 for r in self.results if r["status"] == "auth_required")
        failed = sum(1 for r in self.results if r["status"] in ["failed", "error", "timeout"])
        total = len(self.results)
        
        print(f"总计: {total}")
        print(f"✅ 成功: {success} ({success/total*100:.1f}%)")
        print(f"⚠️  需要认证: {auth_required} ({auth_required/total*100:.1f}%)")
        print(f"❌ 失败: {failed} ({failed/total*100:.1f}%)")
        print("="*60)

def main():
    tester = APITester()
    
    print("="*60)
    print("开始测试修复后的API")
    print("="*60)
    print()
    
    # 1. 测试认证相关API
    print("【认证相关API】")
    tester.test_api("用户信息 (/auth/profile)", "GET", "/auth/profile")
    print()
    
    # 2. 测试关注粉丝API（需要登录）
    print("【关注粉丝API】")
    tester.test_api("关注列表 (/following)", "GET", "/following")
    tester.test_api("粉丝列表 (/followers)", "GET", "/followers")
    print()
    
    # 3. 测试消息相关API（需要登录）
    print("【消息相关API】")
    tester.test_api("对话列表 (/messages/conversations)", "GET", "/messages/conversations")
    tester.test_api("通知列表 (/messages/notifications)", "GET", "/messages/notifications")
    tester.test_api("消息统计 (/messages/stats)", "GET", "/messages/stats")
    print()
    
    # 4. 测试同城服务API
    print("【同城服务API】")
    tester.test_api("同城服务统计 (/local-services/stats)", "GET", "/local-services/stats")
    tester.test_api("宠物店列表 (/local-services/pet-stores)", "GET", "/local-services/pet-stores", params={"page": 1, "page_size": 10})
    tester.test_api("宠物交流 (/local-services/social-posts)", "GET", "/local-services/social-posts", params={"page": 1, "page_size": 10})
    tester.test_api("宠物配种 (/local-services/breeding-info)", "GET", "/local-services/breeding-info", params={"page": 1, "page_size": 10})
    print()
    
    # 5. 测试拍卖相关API
    print("【拍卖相关API】")
    tester.test_api("拍卖结果 (/auctions/results)", "GET", "/auctions/results")
    print()
    
    # 6. 测试搜索API（需要keyword参数）
    print("【搜索API】")
    tester.test_api("商品搜索 (/search?keyword=宠物)", "GET", "/search", params={"keyword": "宠物", "page": 1, "page_size": 10})
    tester.test_api("搜索建议 (/search/suggestions?keyword=宠)", "GET", "/search/suggestions", params={"keyword": "宠", "limit": 5})
    tester.test_api("热门搜索 (/search/hot)", "GET", "/search/hot", params={"limit": 10})
    print()
    
    # 7. 测试首页API
    print("【首页API】")
    tester.test_api("推荐商品 (/home/recommended-products)", "GET", "/home/recommended-products", params={"page": 1, "page_size": 10})
    print()
    
    # 8. 测试管理员API（需要管理员权限）
    print("【管理员API】")
    tester.test_api("管理员仪表板 (/admin/dashboard)", "GET", "/admin/dashboard")
    print()
    
    # 9. 测试其他新增API
    print("【其他API】")
    tester.test_api("抽奖配置 (/lottery/config)", "GET", "/lottery/config")
    tester.test_api("抽奖历史 (/lottery/history)", "GET", "/lottery/history", params={"page": 1, "page_size": 10})
    tester.test_api("店铺列表 (/stores)", "GET", "/stores", params={"page": 1, "page_size": 10})
    tester.test_api("专场活动列表 (/events)", "GET", "/events", params={"page": 1, "page_size": 10})
    tester.test_api("开屏广告列表 (/splash-ads)", "GET", "/splash-ads")
    print()
    
    # 打印测试摘要
    tester.print_summary()
    
    # 如果有登录功能，尝试登录后再测试需要认证的API
    print("\n尝试登录后测试需要认证的API...")
    if tester.login():
        print("\n【重新测试需要认证的API】")
        tester.test_api("用户信息 (/auth/profile)", "GET", "/auth/profile")
        tester.test_api("关注列表 (/following)", "GET", "/following")
        tester.test_api("粉丝列表 (/followers)", "GET", "/followers")
        tester.test_api("对话列表 (/messages/conversations)", "GET", "/messages/conversations")
        tester.test_api("拍卖结果 (/auctions/results)", "GET", "/auctions/results")
        print()
        tester.print_summary()

if __name__ == "__main__":
    main()

