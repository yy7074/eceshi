-- 创建专场活动数据
-- 在服务器上执行: mysql -uroot -p123456 petshop_auction < 创建专场活动.sql

USE petshop_auction;

-- 清除旧数据
DELETE FROM event_products;
DELETE FROM special_events;

-- 插入新专场活动（时间从当前时间开始，持续30天）
INSERT INTO special_events (id, title, description, banner_image, start_time, end_time, is_active, created_at) VALUES
(1, '新春萌宠专场', '新春特惠，精选优质宠物，限时拍卖！', '/static/uploads/event1.jpg', 
 DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 30 DAY), 1, NOW()),

(2, '水族精品专场', '精品观赏鱼和水族用品，打造完美水族世界', '/static/uploads/event2.jpg',
 DATE_SUB(NOW(), INTERVAL 12 HOUR), DATE_ADD(NOW(), INTERVAL 25 DAY), 1, NOW()),

(3, '一口价精选', '精选优质商品，一口价直接购买，无需等待', '/static/uploads/event3.jpg',
 DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_ADD(NOW(), INTERVAL 60 DAY), 1, NOW()),

(4, '爬宠专区', '各类爬行宠物及用品专场', '/static/uploads/event4.jpg',
 NOW(), DATE_ADD(NOW(), INTERVAL 15 DAY), 1, NOW());

-- 验证数据
SELECT 
    id,
    title,
    DATE_FORMAT(start_time, '%Y-%m-%d %H:%i') as 开始时间,
    DATE_FORMAT(end_time, '%Y-%m-%d %H:%i') as 结束时间,
    CASE 
        WHEN is_active = 1 AND NOW() BETWEEN start_time AND end_time THEN '🟢 进行中'
        WHEN is_active = 0 THEN '🔴 已禁用'
        WHEN NOW() < start_time THEN '⏰ 未开始'
        ELSE '⏹️ 已结束'
    END as 状态
FROM special_events
ORDER BY id;

SELECT CONCAT('✅ 成功创建 ', COUNT(*), ' 个专场活动！') as 结果 FROM special_events;

