# API对接详细修复方案

## 📋 问题诊断结果

经过详细检查后端代码，发现的主要问题：

---

## ✅ 已修复的API

### 1. 用户信息API
- **问题**: `/api/v1/auth/profile` 不存在
- **修复**: 在 `backend/app/api/auth.py` 添加了 `/profile` 别名端点
- **状态**: ✅ 已修复

### 2. 推荐商品API
- **问题**: `/api/v1/home/recommended-products` 不存在
- **修复**: 在 `backend/app/api/home.py` 添加了独立的推荐商品端点
- **状态**: ✅ 已修复

---

## ⚠️ 需要Flutter端修复的API路径

### 3. 消息列表API
- **问题**: `/api/v1/messages/` 端点不存在
- **原因**: `messages.py` 没有根路径端点
- **可用端点**:
  ```python
  /api/v1/messages/conversations        # 获取对话列表
  /api/v1/messages/notifications         # 获取通知列表
  /api/v1/messages/send                  # 发送消息
  /api/v1/messages/stats                 # 消息统计
  ```
- **Flutter端修改建议**:
  ```dart
  // 修改前
  static const String messages = '/messages/';
  
  // 修改后（根据需求选择）
  static const String conversations = '/messages/conversations';  // 对话列表
  static const String notifications = '/messages/notifications';  // 通知列表
  ```

### 4. 同城服务API
- **问题**: `/api/v1/local-services/` 根路径不存在
- **原因**: `local_services.py` 只有具体的子路径端点
- **可用端点**:
  ```python
  /api/v1/local-services/social-posts      # 宠物交流
  /api/v1/local-services/breeding-info     # 宠物配种
  /api/v1/local-services/pet-stores        # 本地宠店 ✓
  /api/v1/local-services/aquarium-design   # 鱼缸造景
  /api/v1/local-services/door-services     # 上门服务
  /api/v1/local-services/pet-valuation     # 宠物估价
  /api/v1/local-services/nearby-items      # 附近发现
  /api/v1/local-services/stats             # 统计数据
  ```
- **Flutter端修改建议**:
  ```dart
  // 修改前
  static const String localServices = '/local-services/';
  static const String petStores = '/local-services/stores';  // 错误路径
  
  // 修改后
  static const String localServicesList = '/local-services/stats';  // 统计概览
  static const String petStores = '/local-services/pet-stores';     // 正确路径
  ```

### 5. 关注粉丝API
- **问题**: `/api/v1/follows/following` 路径404
- **原因**: main.py 中 follow router 的 prefix 是 `/api/v1`，不是 `/api/v1/follows`
- **实际可用端点**:
  ```python
  /api/v1/following    # 关注列表
  /api/v1/followers    # 粉丝列表
  /api/v1/follow/{user_id}    # 关注用户
  ```
- **Flutter端修改建议**:
  ```dart
  // 修改前
  static const String following = '/follows/following';
  static const String followers = '/follows/followers';
  
  // 修改后
  static const String following = '/following';
  static const String followers = '/followers';
  ```

### 6. 商品搜索API
- **问题**: `/api/v1/search` 返回500错误
- **原因**: 缺少必填参数 `keyword`
- **正确用法**:
  ```dart
  // 搜索商品时必须提供keyword参数
  final url = '/search?keyword=${Uri.encodeComponent(keyword)}';
  
  // 可选参数
  final url = '/search?keyword=宠物&page=1&page_size=20&sort_by=price';
  ```
- **状态**: API本身没问题，Flutter端调用时需要传递参数

---

## ❌ 仍需后端修复的API

### 7. 拍卖结果API
- **问题**: `/api/v1/auctions/results` 端点不存在
- **需要添加**: 在 `backend/app/api/auctions.py` 添加获取用户拍卖结果的端点
- **建议实现**:
  ```python
  @router.get("/results")
  async def get_auction_results(
      page: int = Query(1, ge=1),
      page_size: int = Query(20, ge=1, le=100),
      status: Optional[str] = Query(None),  # won, lost, pending
      current_user: User = Depends(get_current_user),
      db: Session = Depends(get_db)
  ):
      """获取用户的拍卖结果"""
      # 实现逻辑：查询用户参与的拍卖及结果
      pass
  ```

### 8. 后台管理首页
- **问题**: `/admin/` 返回404
- **原因**: 
  1. `admin/index.html` 文件可能不存在
  2. 或者静态文件路由配置有问题
- **检查步骤**:
  ```bash
  # 1. 检查文件是否存在
  ls -la admin/index.html
  
  # 2. 检查main.py中的admin路由配置
  # 应该在line 41-53
  ```
- **修复**: 确保 `admin/index.html` 文件存在且路径正确

### 9. 管理员仪表板API
- **问题**: `/api/v1/admin/dashboard` 端点不存在
- **需要添加**: 在 `backend/app/api/admin.py` 添加仪表板数据端点
- **建议实现**:
  ```python
  @router.get("/dashboard")
  async def get_dashboard_data(
      current_admin: User = Depends(get_current_admin_user),
      db: Session = Depends(get_db)
  ):
      """获取管理后台仪表板数据"""
      # 统计各种数据：用户数、商品数、订单数等
      pass
  ```

---

## 🐌 性能问题需优化

### 10. 店铺列表超时
- **问题**: `/api/v1/stores/` 请求超时
- **可能原因**:
  1. 数据库查询慢（未建立索引）
  2. 返回数据过多（未分页或分页实现有问题）
  3. 有复杂的关联查询
- **优化建议**:
  ```python
  # 1. 添加数据库索引
  # 在 stores 表上添加常用查询字段的索引
  
  # 2. 优化查询
  # 使用 select_related 或 joinedload 优化关联查询
  
  # 3. 添加缓存
  # 对不常变化的数据使用缓存
  ```

### 11. AI识别服务超时
- **问题**: `/api/v1/ai-recognition` 请求超时
- **可能原因**:
  1. AI服务未启动
  2. 外部API调用超时
  3. 模型加载慢
- **检查步骤**:
  ```bash
  # 检查AI识别相关配置
  cat backend/app/api/ai_recognition.py
  
  # 检查环境变量中的AI服务配置
  cat backend/.env | grep AI
  ```

---

## 📱 Flutter端需要修改的文件清单

### 文件1: `petshop_app/lib/constants/api_constants.dart`
```dart
class ApiConstants {
  // ... 现有代码 ...
  
  // 修改关注粉丝路径
  static const String following = '/following';
  static const String followers = '/followers';
  
  // 添加消息相关路径
  static const String conversations = '/messages/conversations';
  static const String notifications = '/messages/notifications';
  static const String sendMessage = '/messages/send';
  
  // 修改同城服务路径
  static const String petStores = '/local-services/pet-stores';
  static const String localServiceStats = '/local-services/stats';
  
  // 注意：搜索API需要传递keyword参数
  // 使用方式: '$search?keyword=$keyword'
}
```

### 文件2: `petshop_app/lib/services/message_service.dart`
```dart
// 修改消息列表API调用
Future<List<Conversation>> getConversations() async {
  // 修改前: final response = await dio.get('/messages/');
  // 修改后:
  final response = await dio.get('/messages/conversations');
  // ...
}
```

### 文件3: `petshop_app/lib/services/local_service_service.dart`
```dart
// 修改同城服务API调用
Future<List<PetStore>> getPetStores() async {
  // 修改前: final response = await dio.get('/local-services/stores');
  // 修改后:
  final response = await dio.get('/local-services/pet-stores');
  // ...
}
```

### 文件4: `petshop_app/lib/services/follow_service.dart`
```dart
// 修改关注粉丝API调用
Future<FollowList> getFollowing() async {
  // 修改前: final response = await dio.get('/follows/following');
  // 修改后:
  final response = await dio.get('/following');
  // ...
}

Future<FollowList> getFollowers() async {
  // 修改前: final response = await dio.get('/follows/followers');
  // 修改后:
  final response = await dio.get('/followers');
  // ...
}
```

### 文件5: `petshop_app/lib/services/search_service.dart`
```dart
// 确保搜索时传递keyword参数
Future<SearchResult> searchProducts(String keyword) async {
  if (keyword.isEmpty) {
    throw Exception('搜索关键词不能为空');
  }
  
  final response = await dio.get(
    '/search',
    queryParameters: {
      'keyword': keyword,
      'page': 1,
      'page_size': 20,
    },
  );
  // ...
}
```

---

## 🎯 修复优先级和时间估算

| 优先级 | 任务 | 估算时间 | 状态 |
|--------|------|----------|------|
| P0 | ✅ 用户信息API | 5分钟 | 已完成 |
| P0 | ✅ 推荐商品API | 10分钟 | 已完成 |
| P1 | Flutter端关注粉丝路径 | 5分钟 | 待修复 |
| P1 | Flutter端消息路径 | 5分钟 | 待修复 |
| P1 | Flutter端同城服务路径 | 5分钟 | 待修复 |
| P1 | 搜索参数验证 | 5分钟 | 待修复 |
| P2 | 拍卖结果API | 30分钟 | 待开发 |
| P2 | 店铺列表性能优化 | 1小时 | 待优化 |
| P3 | 后台管理仪表板API | 1小时 | 待开发 |
| P3 | AI识别服务调试 | 2小时 | 待调试 |

---

## 🚀 立即执行计划

### 第一步：修复Flutter端API路径（15分钟）
1. 修改 `api_constants.dart`
2. 修改相关service文件
3. 测试验证

### 第二步：测试已修复的后端API（5分钟）
```bash
# 重启后端服务（如果需要）
cd backend
python main.py

# 运行API检查脚本
python check_all_apis.py
```

### 第三步：验证整体功能（10分钟）
1. 启动Flutter应用
2. 测试关注/粉丝功能
3. 测试消息功能
4. 测试同城服务功能
5. 测试商品搜索功能

---

## ✅ 预期结果

修复后的API成功率应该从 **40.6%** 提升到 **70%+**

剩余未实现的功能（拍卖结果、后台仪表板等）可以在后续迭代中完善。

---

## 📞 如果遇到问题

1. 后端API不响应 → 检查服务器是否运行
2. Flutter调用失败 → 检查API路径和参数
3. 数据返回为空 → 检查数据库数据是否存在
4. 性能问题 → 使用数据库查询分析工具定位慢查询

