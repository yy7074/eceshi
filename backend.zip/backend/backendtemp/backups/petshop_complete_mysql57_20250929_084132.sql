-- MySQL 5.7 Compatible Database Backup (完整备份)
-- Generated on: 2025-09-29 08:41:32
-- Database: petshop_auction
-- Host: localhost:3306
-- Compatible with MySQL 5.7+
-- Charset: utf8mb4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_model_metrics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模型版本',
  `model_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模型类型',
  `accuracy` decimal(5,4) DEFAULT NULL COMMENT '准确率',
  `precision` decimal(5,4) DEFAULT NULL COMMENT '精确率',
  `recall` decimal(5,4) DEFAULT NULL COMMENT '召回率',
  `f1_score` decimal(5,4) DEFAULT NULL COMMENT 'F1分数',
  `total_predictions` int DEFAULT NULL COMMENT '总预测次数',
  `correct_predictions` int DEFAULT NULL COMMENT '正确预测次数',
  `avg_confidence` decimal(5,4) DEFAULT NULL COMMENT '平均置信度',
  `avg_processing_time` decimal(8,3) DEFAULT NULL COMMENT '平均处理时间(秒)',
  `metrics_date` datetime NOT NULL COMMENT '指标日期',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_ai_model_metrics_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_recognition_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `recognition_id` int NOT NULL,
  `user_id` int NOT NULL,
  `feedback_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '反馈类型: correct(正确), incorrect(错误), partial(部分正确)',
  `correct_breed` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户认为的正确品种',
  `comments` text COLLATE utf8mb4_unicode_ci COMMENT '用户评论',
  `rating` int DEFAULT NULL COMMENT '评分(1-5)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_ai_recognition_feedback_recognition_id` (`recognition_id`),
  KEY `ix_ai_recognition_feedback_id` (`id`),
  KEY `ix_ai_recognition_feedback_user_id` (`user_id`),
  CONSTRAINT `ai_recognition_feedback_ibfk_1` FOREIGN KEY (`recognition_id`) REFERENCES `ai_recognition_records` (`id`),
  CONSTRAINT `ai_recognition_feedback_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_recognition_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '宠物类型',
  `breed` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '品种名称',
  `confidence` decimal(5,4) NOT NULL COMMENT '置信度',
  `result_data` json DEFAULT NULL COMMENT '完整识别结果数据',
  `image_format` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片格式',
  `image_size` int DEFAULT NULL COMMENT '图片大小(字节)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态: pending(处理中), completed(完成), failed(失败)',
  `error_message` text COLLATE utf8mb4_unicode_ci COMMENT '错误信息',
  `processing_time` decimal(8,3) DEFAULT NULL COMMENT '处理耗时(秒)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_ai_recognition_records_user_id` (`user_id`),
  KEY `ix_ai_recognition_records_id` (`id`),
  CONSTRAINT `ai_recognition_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `ai_recognition_records` VALUES (1,1,'狗','拉布拉多',0.7487,'{\"breed\": \"拉布拉多\", \"pet_type\": \"狗\", \"confidence\": 0.7486622046596108, \"care_advice\": [\"充足运动\", \"游泳训练\", \"定期护理\", \"早期社交\"], \"health_tips\": [\"预防肥胖\", \"关注眼部健康\", \"定期疫苗\"], \"feeding_guide\": [\"控制食量\", \"优质蛋白\", \"定时喂养\"], \"characteristics\": [\"活泼\", \"友好\", \"易训练\", \"温和\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 6000, \"min_price\": 1200}, \"popularity_score\": 0.95, \"alternative_breeds\": [{\"breed\": \"金毛寻回犬\", \"similarity\": 0.8, \"characteristics\": [\"温顺\", \"聪明\"]}, {\"breed\": \"哈士奇\", \"similarity\": 0.8, \"characteristics\": [\"独立\", \"活跃\"]}]}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:17:51','2025-09-19 17:17:51'),(2,1,'猫','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:20:06','2025-09-19 17:20:06'),(3,1,'鸟','虎皮鹦鹉',0.6688,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.6687961930301399, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:20:21','2025-09-19 17:20:21'),(4,1,'鸟','虎皮鹦鹉',0.7725,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.7725232493945904, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:22:33','2025-09-19 17:22:33'),(5,1,'猫','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:22:35','2025-09-19 17:22:35'),(6,1,'猫','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-19 17:23:38','2025-09-19 17:23:38'),(7,1,'狗','金毛寻回犬',0.6685,'{\"breed\": \"金毛寻回犬\", \"pet_type\": \"狗\", \"confidence\": 0.6684743340764616, \"care_advice\": [\"需要大量运动\", \"定期梳毛\", \"注意饮食控制\", \"社交训练\"], \"health_tips\": [\"预防髋关节发育不良\", \"定期心脏检查\", \"控制体重\"], \"feeding_guide\": [\"高质量狗粮\", \"分餐喂养\", \"避免过度喂食\"], \"characteristics\": [\"温顺\", \"聪明\", \"友善\", \"忠诚\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 8000, \"min_price\": 1500}, \"popularity_score\": 0.9, \"alternative_breeds\": [{\"breed\": \"拉布拉多\", \"similarity\": 0.8, \"characteristics\": [\"活泼\", \"友好\"]}, {\"breed\": \"哈士奇\", \"similarity\": 0.8, \"characteristics\": [\"独立\", \"活跃\"]}]}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:12:56','2025-09-20 09:12:56'),(8,1,'猫','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:12:59','2025-09-20 09:12:59'),(9,1,'鸟','虎皮鹦鹉',0.3345,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.3344879232584251, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:16:16','2025-09-20 09:16:16'),(10,1,'猫','未知品种',0.5900,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.59, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:16:19','2025-09-20 09:16:19'),(11,1,'鸟','虎皮鹦鹉',0.4123,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.4122659053174631, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:16:48','2025-09-20 09:16:48'),(12,1,'猫','未知品种',0.3600,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.36, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:16:50','2025-09-20 09:16:50'),(13,1,'猫','英国短毛猫',0.6514,'{\"breed\": \"英国短毛猫\", \"pet_type\": \"猫\", \"confidence\": 0.6513919081471662, \"care_advice\": [\"定期梳毛\", \"清洁耳朵\", \"指甲修剪\", \"环境丰富\"], \"health_tips\": [\"预防肥厚性心肌病\", \"定期口腔护理\", \"控制体重\"], \"feeding_guide\": [\"高蛋白猫粮\", \"定时定量\", \"新鲜水源\"], \"characteristics\": [\"温和\", \"独立\", \"安静\", \"友善\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 8000, \"min_price\": 2000}, \"popularity_score\": 0.85, \"alternative_breeds\": [{\"breed\": \"布偶猫\", \"similarity\": 0.8, \"characteristics\": [\"温顺\", \"粘人\"]}]}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:16:53','2025-09-20 09:16:53'),(14,1,'猫','英国短毛猫',0.3409,'{\"breed\": \"英国短毛猫\", \"pet_type\": \"猫\", \"confidence\": 0.34090592092295835, \"care_advice\": [\"定期梳毛\", \"清洁耳朵\", \"指甲修剪\", \"环境丰富\"], \"health_tips\": [\"预防肥厚性心肌病\", \"定期口腔护理\", \"控制体重\"], \"feeding_guide\": [\"高蛋白猫粮\", \"定时定量\", \"新鲜水源\"], \"characteristics\": [\"温和\", \"独立\", \"安静\", \"友善\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 8000, \"min_price\": 2000}, \"popularity_score\": 0.85, \"alternative_breeds\": [{\"breed\": \"布偶猫\", \"similarity\": 0.8, \"characteristics\": [\"温顺\", \"粘人\"]}]}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:17:06','2025-09-20 09:17:06'),(15,1,'鸟','虎皮鹦鹉',0.3057,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.3057366395640193, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:17:08','2025-09-20 09:17:08'),(16,1,'狗','哈士奇',0.4260,'{\"breed\": \"哈士奇\", \"pet_type\": \"狗\", \"confidence\": 0.4259521531174459, \"care_advice\": [\"大量运动\", \"耐寒训练\", \"坚持训练\", \"安全围栏\"], \"health_tips\": [\"预防白内障\", \"关注关节健康\", \"定期体检\"], \"feeding_guide\": [\"高能量食物\", \"分餐制\", \"充足水分\"], \"characteristics\": [\"独立\", \"活跃\", \"聪明\", \"顽皮\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 10000, \"min_price\": 2000}, \"popularity_score\": 0.8, \"alternative_breeds\": [{\"breed\": \"金毛寻回犬\", \"similarity\": 0.8, \"characteristics\": [\"温顺\", \"聪明\"]}, {\"breed\": \"拉布拉多\", \"similarity\": 0.8, \"characteristics\": [\"活泼\", \"友好\"]}]}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:17:10','2025-09-20 09:17:10'),(17,1,'鸟','虎皮鹦鹉',0.5643,'{\"breed\": \"虎皮鹦鹉\", \"pet_type\": \"鸟\", \"confidence\": 0.564283459646914, \"care_advice\": [\"宽敞鸟笼\", \"定期清洁\", \"社交互动\", \"飞行空间\"], \"health_tips\": [\"预防呼吸道疾病\", \"注意营养平衡\", \"定期体检\"], \"feeding_guide\": [\"专用鸟粮\", \"新鲜蔬果\", \"清洁饮水\"], \"characteristics\": [\"活泼\", \"聪明\", \"善模仿\", \"社交\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 200, \"min_price\": 50}, \"popularity_score\": 0.7, \"alternative_breeds\": []}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:18:13','2025-09-20 09:18:13'),(18,1,'狗','拉布拉多',0.6587,'{\"breed\": \"拉布拉多\", \"pet_type\": \"狗\", \"confidence\": 0.6586608965910992, \"care_advice\": [\"充足运动\", \"游泳训练\", \"定期护理\", \"早期社交\"], \"health_tips\": [\"预防肥胖\", \"关注眼部健康\", \"定期疫苗\"], \"feeding_guide\": [\"控制食量\", \"优质蛋白\", \"定时喂养\"], \"characteristics\": [\"活泼\", \"友好\", \"易训练\", \"温和\"], \"estimated_value\": {\"note\": \"价格仅供参考，实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 6000, \"min_price\": 1200}, \"popularity_score\": 0.95, \"alternative_breeds\": [{\"breed\": \"金毛寻回犬\", \"similarity\": 0.8, \"characteristics\": [\"温顺\", \"聪明\"]}, {\"breed\": \"哈士奇\", \"similarity\": 0.8, \"characteristics\": [\"独立\", \"活跃\"]}]}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:18:18','2025-09-20 09:18:18'),(19,1,'猫','未知品种',0.6400,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.64, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:18:49','2025-09-20 09:18:49'),(20,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:19:01','2025-09-20 09:19:01'),(21,1,'猫','未知品种',0.6400,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.64, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:20:00','2025-09-20 09:20:00'),(22,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:20:06','2025-09-20 09:20:06'),(23,1,'猫','未知品种',0.6400,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.64, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:22:55','2025-09-20 09:22:55'),(24,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:05','2025-09-20 09:23:05'),(25,1,'unknown','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"unknown\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:12','2025-09-20 09:23:12'),(26,1,'狗','未知品种',0.9400,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.94, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:13','2025-09-20 09:23:13'),(27,1,'unknown','未知品种',0.0000,'{\"breed\": \"未知品种\", \"pet_type\": \"unknown\", \"confidence\": 0.0, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:15','2025-09-20 09:23:15'),(28,1,'猫','未知品种',0.8800,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.88, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:36','2025-09-20 09:23:36'),(29,1,'猫','未知品种',0.6400,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.64, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:49','2025-09-20 09:23:49'),(30,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:23:55','2025-09-20 09:23:55'),(31,1,'猫','未知品种',0.6400,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.64, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:25:05','2025-09-20 09:25:05'),(32,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:25:07','2025-09-20 09:25:07'),(33,1,'狗','未知品种',0.9200,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.92, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:25:19','2025-09-20 09:25:19'),(34,2,'狗','未知品种',0.8300,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.83, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:31:22','2025-09-20 09:31:22'),(35,2,'狗','未知品种',0.8300,'{\"breed\": \"未知品种\", \"pet_type\": \"狗\", \"confidence\": 0.83, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:31:26','2025-09-20 09:31:26'),(36,2,'猫','未知品种',0.3000,'{\"breed\": \"未知品种\", \"pet_type\": \"猫\", \"confidence\": 0.3, \"care_advice\": [], \"health_tips\": [], \"feeding_guide\": [], \"characteristics\": [], \"estimated_value\": null}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:31:54','2025-09-20 09:31:54'),(37,1,'猫','土耳其安哥拉猫',0.8900,'{\"breed\": \"土耳其安哥拉猫\", \"pet_type\": \"猫\", \"confidence\": 0.89, \"care_advice\": [\"提供猫砂盆\", \"定期梳毛\", \"注意口腔健康\", \"提供抓板\"], \"health_tips\": [\"预防泌尿系统疾病\", \"定期驱虫\", \"关注眼部健康\", \"预防肥胖\"], \"feeding_guide\": [\"高蛋白猫粮\", \"适量湿粮\", \"避免牛奶\", \"控制零食量\"], \"characteristics\": [\"独立\", \"优雅\", \"敏捷\", \"聪明\"], \"estimated_value\": {\"note\": \"价格仅供参考，土耳其安哥拉猫的实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 5000, \"min_price\": 500}, \"raw_predictions\": [{\"breed\": \"土耳其安哥拉猫\", \"confidence\": 0.89, \"chinese_name\": \"土耳其安哥拉猫\", \"english_name\": \"Turkish Angora\"}, {\"breed\": \"缅因猫\", \"confidence\": 0.04, \"chinese_name\": \"缅因猫\", \"english_name\": \"Maine Coon Cat\"}, {\"breed\": \"泰国御猫\", \"confidence\": 0.01, \"chinese_name\": \"泰国御猫\", \"english_name\": \"Khao Manee\"}]}','url',NULL,'completed',NULL,NULL,'2025-09-20 09:33:38','2025-09-20 09:33:38'),(38,2,'猫','伯曼猫',0.3600,'{\"breed\": \"伯曼猫\", \"pet_type\": \"猫\", \"confidence\": 0.36, \"care_advice\": [\"提供猫砂盆\", \"定期梳毛\", \"注意口腔健康\", \"提供抓板\"], \"health_tips\": [\"预防泌尿系统疾病\", \"定期驱虫\", \"关注眼部健康\", \"预防肥胖\"], \"feeding_guide\": [\"高蛋白猫粮\", \"适量湿粮\", \"避免牛奶\", \"控制零食量\"], \"characteristics\": [\"独立\", \"优雅\", \"敏捷\", \"聪明\"], \"estimated_value\": {\"note\": \"价格仅供参考，伯曼猫的实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 5000, \"min_price\": 500}, \"raw_predictions\": [{\"breed\": \"伯曼猫\", \"confidence\": 0.36, \"chinese_name\": \"伯曼猫\", \"english_name\": \"Birman\"}, {\"breed\": \"泰国御猫\", \"confidence\": 0.16, \"chinese_name\": \"泰国御猫\", \"english_name\": \"Khao Manee\"}, {\"breed\": \"土耳其安哥拉猫\", \"confidence\": 0.12, \"chinese_name\": \"土耳其安哥拉猫\", \"english_name\": \"Turkish Angora\"}]}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:34:24','2025-09-20 09:34:24'),(39,2,'狗','奇努克犬',0.5800,'{\"breed\": \"奇努克犬\", \"pet_type\": \"狗\", \"confidence\": 0.58, \"care_advice\": [\"每天需要运动\", \"定期梳毛\", \"注意饮食营养\", \"定期疫苗接种\"], \"health_tips\": [\"关注关节健康\", \"预防皮肤病\", \"定期体检\", \"注意体重控制\"], \"feeding_guide\": [\"优质狗粮为主\", \"适量肉类\", \"避免巧克力等有害食物\", \"充足饮水\"], \"characteristics\": [\"忠诚\", \"友善\", \"活泼\", \"聪明\"], \"estimated_value\": {\"note\": \"价格仅供参考，奇努克犬的实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 8000, \"min_price\": 800}, \"raw_predictions\": [{\"breed\": \"奇努克犬\", \"confidence\": 0.58, \"chinese_name\": \"奇努克犬\", \"english_name\": \"Chinook Dog\"}, {\"breed\": \"博美犬\", \"confidence\": 0.17, \"chinese_name\": \"博美犬\", \"english_name\": \"Pomeranian\"}, {\"breed\": \"金毛寻回犬\", \"confidence\": 0.1, \"chinese_name\": \"金毛寻回犬\", \"english_name\": \"Golden Retriever\"}]}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:34:38','2025-09-20 09:34:38'),(40,2,'狗','比利时玛利诺犬',0.9400,'{\"breed\": \"比利时玛利诺犬\", \"pet_type\": \"狗\", \"confidence\": 0.94, \"care_advice\": [\"每天需要运动\", \"定期梳毛\", \"注意饮食营养\", \"定期疫苗接种\"], \"health_tips\": [\"关注关节健康\", \"预防皮肤病\", \"定期体检\", \"注意体重控制\"], \"feeding_guide\": [\"优质狗粮为主\", \"适量肉类\", \"避免巧克力等有害食物\", \"充足饮水\"], \"characteristics\": [\"忠诚\", \"友善\", \"活泼\", \"聪明\"], \"estimated_value\": {\"note\": \"价格仅供参考，比利时玛利诺犬的实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 8000, \"min_price\": 800}, \"raw_predictions\": [{\"breed\": \"比利时玛利诺犬\", \"confidence\": 0.94, \"chinese_name\": \"比利时玛利诺犬\", \"english_name\": \"Belgian Malinois\"}]}','jpg',NULL,'completed',NULL,NULL,'2025-09-20 09:37:48','2025-09-20 09:37:48'),(41,14,'猫','英国短毛猫',0.8500,'{\"breed\": \"英国短毛猫\", \"pet_type\": \"猫\", \"confidence\": 0.85, \"care_advice\": [\"提供猫砂盆\", \"定期梳毛\", \"注意口腔健康\", \"提供抓板\"], \"health_tips\": [\"预防泌尿系统疾病\", \"定期驱虫\", \"关注眼部健康\", \"预防肥胖\"], \"feeding_guide\": [\"高蛋白猫粮\", \"适量湿粮\", \"避免牛奶\", \"控制零食量\"], \"characteristics\": [\"独立\", \"优雅\", \"敏捷\", \"聪明\"], \"estimated_value\": {\"note\": \"价格仅供参考，英国短毛猫的实际价格受多种因素影响\", \"factors\": [\"年龄和健康状况\", \"血统和证书\", \"外观和品相\", \"训练程度\", \"地区市场差异\"], \"currency\": \"CNY\", \"max_price\": 5000, \"min_price\": 500}, \"raw_predictions\": [{\"breed\": \"英国短毛猫\", \"confidence\": 0.85, \"chinese_name\": \"英国短毛猫\", \"english_name\": \"British Shorthair\"}, {\"breed\": \"异国短毛猫\", \"confidence\": 0.02, \"chinese_name\": \"异国短毛猫\", \"english_name\": \"Exotic\"}, {\"breed\": \"柯尼斯卷毛猫\", \"confidence\": 0.02, \"chinese_name\": \"柯尼斯卷毛猫\", \"english_name\": \"Cornish Rex\"}]}','png',NULL,'completed',NULL,NULL,'2025-09-28 14:44:18','2025-09-28 14:44:18');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aquarium_design_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tank_sizes` text COLLATE utf8mb4_unicode_ci,
  `design_styles` text COLLATE utf8mb4_unicode_ci,
  `price_range` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_images` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_wechat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `order_count` int DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_id` (`provider_id`),
  KEY `ix_aquarium_design_services_id` (`id`),
  CONSTRAINT `aquarium_design_services_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `aquarium_design_services` VALUES (1,1,'专业水族造景设计','10年水族造景经验，提供个性化设计方案，包含植物搭配、石材布局、lighting设计等','[\"30cm\", \"60cm\", \"90cm\", \"120cm\", \"\\u5b9a\\u5236\\u5c3a\\u5bf8\"]','[\"\\u81ea\\u7136\\u98ce\", \"\\u7b80\\u7ea6\\u98ce\", \"\\u70ed\\u5e26\\u98ce\", \"\\u6d77\\u6c34\\u98ce\"]','500-5000元','[\"/static/uploads/aquarium1.jpg\", \"/static/uploads/aquarium2.jpg\"]','北京市海淀区','156****9876','aquarium_master',4.9,45,1,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto_bids` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `max_amount` decimal(10,2) NOT NULL,
  `increment_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'active:活跃, paused:暂停, completed:完成, cancelled:取消',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_auto_bids_id` (`id`),
  KEY `ix_auto_bids_product_id` (`product_id`),
  KEY `ix_auto_bids_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bids` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `bidder_id` int NOT NULL,
  `bid_amount` decimal(10,2) NOT NULL,
  `is_auto_bid` tinyint(1) DEFAULT NULL,
  `max_bid_amount` decimal(10,2) DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1:有效,2:被超越,3:撤销',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_bids_id` (`id`),
  KEY `ix_bids_bidder_id` (`bidder_id`),
  KEY `ix_bids_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `bids` VALUES (1,4,1,2600.00,0,NULL,2,'2025-09-13 21:25:51'),(2,4,1,2900.00,0,NULL,2,'2025-09-13 21:27:28'),(3,4,1,3000.00,0,NULL,2,'2025-09-13 21:27:52'),(4,4,1,3100.00,0,NULL,2,'2025-09-13 21:28:17'),(5,4,1,3200.00,0,NULL,1,'2025-09-13 21:28:45'),(6,1,2,820.00,0,NULL,2,'2025-09-14 01:22:13'),(7,1,2,830.00,0,NULL,2,'2025-09-14 01:22:35'),(8,1,2,900.00,0,NULL,2,'2025-09-14 07:52:23'),(9,1,2,910.00,0,NULL,2,'2025-09-14 08:14:21'),(10,5,2,810.00,0,NULL,1,'2025-09-14 11:26:16'),(11,2,2,810.00,0,NULL,2,'2025-09-14 12:19:23'),(12,2,2,830.00,0,NULL,2,'2025-09-14 14:00:42'),(13,2,9,840.00,0,NULL,2,'2025-09-14 18:28:23'),(14,2,2,860.00,0,NULL,2,'2025-09-14 18:31:21'),(15,2,2,890.00,0,NULL,2,'2025-09-14 18:31:45'),(16,2,2,920.00,0,NULL,2,'2025-09-14 18:47:27'),(17,2,2,940.00,0,NULL,2,'2025-09-14 20:17:28'),(18,1,12,940.00,0,NULL,1,'2025-09-19 18:04:04'),(19,2,12,960.00,0,NULL,2,'2025-09-19 18:04:19'),(20,10,2,120.00,0,NULL,1,'2025-09-19 19:19:35'),(21,2,2,970.00,0,NULL,1,'2025-09-19 19:19:44'),(22,11,2,520.00,0,NULL,1,'2025-09-19 19:26:42'),(23,3,2,100.00,0,NULL,1,'2025-09-19 22:14:41'),(24,12,2,370.00,0,NULL,1,'2025-09-19 22:19:46');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `browse_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `product_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_price` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_browse_histories_user_id` (`user_id`),
  KEY `ix_browse_histories_product_id` (`product_id`),
  KEY `ix_browse_histories_id` (`id`),
  CONSTRAINT `browse_histories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `browse_histories_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int DEFAULT NULL,
  `icon_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_categories_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `categories` VALUES (1,'宠物',0,'https://picsum.photos/64/64?random=cat',1,1,'2025-09-13 19:55:57','2025-09-13 19:55:57'),(2,'水族',0,'https://picsum.photos/64/64?random=fish',2,1,'2025-09-13 19:55:57','2025-09-13 19:55:57'),(3,'用品',0,'https://picsum.photos/64/64?random=toy',3,1,'2025-09-13 19:55:57','2025-09-13 19:55:57');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user1_id` int NOT NULL,
  `user2_id` int NOT NULL,
  `last_message_id` int DEFAULT NULL,
  `last_message_time` datetime DEFAULT NULL,
  `user1_unread_count` int DEFAULT NULL,
  `user2_unread_count` int DEFAULT NULL,
  `user1_deleted` tinyint(1) DEFAULT NULL,
  `user2_deleted` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user2_id` (`user2_id`),
  KEY `last_message_id` (`last_message_id`),
  KEY `ix_conversations_id` (`id`),
  KEY `idx_conversation_users` (`user1_id`,`user2_id`),
  KEY `idx_conversation_last_message_time` (`last_message_time`),
  CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`user1_id`) REFERENCES `users` (`id`),
  CONSTRAINT `conversations_ibfk_2` FOREIGN KEY (`user2_id`) REFERENCES `users` (`id`),
  CONSTRAINT `conversations_ibfk_3` FOREIGN KEY (`last_message_id`) REFERENCES `messages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `conversations` VALUES (1,2,2,22,'2025-09-14 18:48:13',0,0,0,0,'2025-09-14 12:06:30','2025-09-14 18:48:13'),(4,1,2,NULL,'2025-09-14 09:26:11',0,0,0,0,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(5,1,3,NULL,'2025-09-14 08:26:11',0,0,0,0,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(6,2,3,NULL,'2025-09-14 04:26:11',0,0,0,0,'2025-09-14 14:26:10','2025-09-14 14:36:55'),(7,2,13,23,'2025-09-19 22:19:52',0,1,0,0,'2025-09-19 22:19:52','2025-09-19 22:19:52'),(8,2,14,26,'2025-09-28 14:36:22',3,0,0,0,'2025-09-28 14:35:48','2025-09-28 14:36:22');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deposit_id` int NOT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作类型: pay(缴纳), freeze(冻结), unfreeze(解冻), refund(退还), forfeit(没收)',
  `amount` decimal(10,2) NOT NULL,
  `operator_id` int DEFAULT NULL COMMENT '操作人ID，系统操作时为空',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作原因',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  KEY `ix_deposit_logs_deposit_id` (`deposit_id`),
  KEY `ix_deposit_logs_id` (`id`),
  CONSTRAINT `deposit_logs_ibfk_1` FOREIGN KEY (`deposit_id`) REFERENCES `deposits` (`id`),
  CONSTRAINT `deposit_logs_ibfk_2` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `deposit_logs` VALUES (1,1,'pay',300.00,2,'用户缴纳保证金','2025-09-14 11:46:32');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `auction_id` int DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '缴纳类型: auction(拍卖保证金), general(通用保证金)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态: active(活跃), frozen(冻结), refunded(已退还), forfeited(没收)',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式: balance(余额支付), alipay(支付宝)',
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交易单号',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `refunded_at` datetime DEFAULT NULL COMMENT '退还时间',
  PRIMARY KEY (`id`),
  KEY `ix_deposits_user_id` (`user_id`),
  KEY `ix_deposits_auction_id` (`auction_id`),
  KEY `ix_deposits_id` (`id`),
  CONSTRAINT `deposits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `deposits` VALUES (1,2,NULL,300.00,'general','active','general保证金','balance','DEPOSIT_202509141146322','2025-09-14 11:46:32','2025-09-14 11:46:32',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `door_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `service_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_area` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `duration` int DEFAULT NULL,
  `equipment_needed` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` float DEFAULT NULL,
  `order_count` int DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_id` (`provider_id`),
  KEY `ix_door_services_id` (`id`),
  CONSTRAINT `door_services_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `door_services` VALUES (1,2,'宠物美容上门服务','美容','专业宠物美容师上门服务，包括洗澡、剪毛、修甲、清耳等','北京市三环内',120,90,'提供专业美容工具和设备','[\"/static/uploads/grooming_service.jpg\"]','187****5432',4.7,78,1,'ACTIVE','2025-09-19 11:34:55',NULL),(2,3,'宠物医疗上门服务','医疗','专业兽医上门服务，疫苗接种、健康检查、简单治疗','上海市内环内',200,60,'携带基础医疗设备','[\"/static/uploads/vet_service.jpg\"]','135****8765',4.9,34,1,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `product_id` int NOT NULL,
  `sort_order` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_event_products_event_id` (`event_id`),
  KEY `ix_event_products_id` (`id`),
  KEY `ix_event_products_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `event_products` VALUES (1,1,1,1,'2025-09-13 19:55:57'),(2,1,2,2,'2025-09-13 19:55:57'),(5,3,5,1,'2025-09-13 19:55:57'),(6,3,6,2,'2025-09-13 19:55:57'),(7,2,3,1,'2025-09-19 17:47:59'),(8,2,4,2,'2025-09-19 17:47:59'),(9,4,10,1,'2025-09-19 17:50:54'),(10,4,11,2,'2025-09-19 17:50:54'),(11,4,12,3,'2025-09-19 17:50:54'),(12,4,13,4,'2025-09-19 17:50:54'),(13,4,14,5,'2025-09-19 17:50:54');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keyword_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `keyword` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_keyword_subscriptions_id` (`id`),
  KEY `ix_keyword_subscriptions_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_pet_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `business_hours` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `services` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `rating` float DEFAULT NULL,
  `review_count` int DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_local_pet_stores_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `local_pet_stores` VALUES (1,'爱宠天地宠物店','张老板','010-12345678','北京市朝阳区望京SOHO塔1-2011',39.9951,116.472,'9:00-21:00','[\"\\u5ba0\\u7269\\u7528\\u54c1\", \"\\u5ba0\\u7269\\u7f8e\\u5bb9\", \"\\u5ba0\\u7269\\u5bc4\\u517b\", \"\\u5ba0\\u7269\\u533b\\u7597\"]','[\"/static/uploads/petstore1.jpg\"]','专业宠物服务连锁店，提供一站式宠物服务',4.8,156,1,'ACTIVE','2025-09-19 11:34:55',NULL),(2,'萌宠乐园','李经理','021-87654321','上海市浦东新区陆家嘴金融中心',31.2304,121.474,'8:30-20:30','[\"\\u5ba0\\u7269\\u7528\\u54c1\", \"\\u5ba0\\u7269\\u98df\\u54c1\", \"\\u5ba0\\u7269\\u73a9\\u5177\"]','[\"/static/uploads/petstore2.jpg\"]','高端宠物用品专卖店',4.6,89,1,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_pickup_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `pickup_location` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `available_times` text COLLATE utf8mb4_unicode_ci,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `ix_local_pickup_services_id` (`id`),
  CONSTRAINT `local_pickup_services_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `local_pickup_services_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_service_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  `parent_id` int DEFAULT NULL COMMENT '父评论ID，用于回复',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论内容',
  `images` json DEFAULT NULL COMMENT '评论图片',
  `status` int DEFAULT NULL COMMENT '状态: 1:正常, 2:隐藏, 3:删除',
  `like_count` int DEFAULT NULL COMMENT '点赞数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `ix_local_service_comments_service_id` (`service_id`),
  KEY `ix_local_service_comments_user_id` (`user_id`),
  KEY `ix_local_service_comments_id` (`id`),
  CONSTRAINT `local_service_comments_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `local_services` (`id`),
  CONSTRAINT `local_service_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `local_service_comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `local_service_comments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_service_favorites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_local_service_favorites_id` (`id`),
  KEY `ix_local_service_favorites_user_id` (`user_id`),
  KEY `ix_local_service_favorites_service_id` (`service_id`),
  CONSTRAINT `local_service_favorites_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `local_services` (`id`),
  CONSTRAINT `local_service_favorites_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_service_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_local_service_likes_service_id` (`service_id`),
  KEY `ix_local_service_likes_id` (`id`),
  KEY `ix_local_service_likes_user_id` (`user_id`),
  CONSTRAINT `local_service_likes_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `local_services` (`id`),
  CONSTRAINT `local_service_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_service_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '发布用户ID',
  `service_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '服务类型: pet_social, local_store, aquarium_design, door_service',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '服务标题',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '服务描述',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '详细内容',
  `province` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份',
  `city` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市',
  `district` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区县',
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '详细地址',
  `latitude` decimal(10,7) DEFAULT NULL COMMENT '纬度',
  `longitude` decimal(10,7) DEFAULT NULL COMMENT '经度',
  `price` decimal(10,2) DEFAULT NULL COMMENT '服务价格',
  `price_unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '价格单位',
  `contact_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `contact_wechat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信号',
  `extra_data` json DEFAULT NULL COMMENT '额外数据，根据服务类型存储不同字段',
  `images` json DEFAULT NULL COMMENT '图片URLs列表',
  `tags` json DEFAULT NULL COMMENT '标签列表',
  `status` int DEFAULT NULL COMMENT '状态: 1:正常, 2:下架, 3:删除',
  `is_featured` tinyint(1) DEFAULT NULL COMMENT '是否推荐',
  `view_count` int DEFAULT NULL COMMENT '浏览次数',
  `like_count` int DEFAULT NULL COMMENT '点赞数',
  `comment_count` int DEFAULT NULL COMMENT '评论数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_local_service_posts_id` (`id`),
  KEY `ix_local_service_posts_user_id` (`user_id`),
  CONSTRAINT `local_service_posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `local_service_posts` VALUES (1,1,'local_store','萌宠天地 - 专业宠物用品店','提供各类宠物用品、食品和玩具，品质保证，价格实惠','我们是一家专业的宠物用品店，经营各种宠物食品、玩具、用品等。店内商品齐全，价格合理，欢迎各位宠物主人前来选购！','北京市','北京','朝阳区','朝阳区三里屯SOHO A座1001',NULL,NULL,0.00,'元','张老板','13800138001',NULL,NULL,'[\"https://picsum.photos/400/300?random=2001\", \"https://picsum.photos/400/300?random=2002\"]','[\"宠物用品\", \"食品\", \"玩具\", \"专业\"]',1,0,456,32,8,'2025-09-14 13:19:02','2025-09-14 13:19:02'),(2,1,'local_store','爱宠医院 - 24小时宠物医疗','专业宠物医疗服务，24小时急诊，经验丰富的兽医团队','本院拥有先进的医疗设备和经验丰富的兽医团队，提供宠物体检、疫苗接种、疾病治疗等全方位医疗服务。','上海市','上海','浦东新区','浦东新区陆家嘴金融中心B座',NULL,NULL,100.00,'起','李医生','13800138002',NULL,NULL,'[\"https://picsum.photos/400/300?random=2003\", \"https://picsum.photos/400/300?random=2004\"]','[\"宠物医院\", \"24小时\", \"专业医疗\"]',1,0,789,56,23,'2025-09-14 13:19:02','2025-09-14 13:19:02'),(3,1,'aquarium_design','专业水族造景设计','提供个性化水族箱造景设计，从设计到施工一站式服务','我们是专业的水族造景团队，拥有多年的设计和施工经验。可以根据客户需求设计各种风格的水族景观，包括自然风、现代简约风等。','广东省','深圳','南山区','南山区科技园创业大厦',NULL,NULL,500.00,'起','王师傅','13800138003',NULL,NULL,'[\"https://picsum.photos/400/300?random=3001\", \"https://picsum.photos/400/300?random=3002\"]','[\"水族造景\", \"专业设计\", \"一站式服务\"]',1,0,345,28,12,'2025-09-14 13:19:02','2025-09-14 13:19:02'),(4,1,'aquarium_design','海水缸定制服务','专业海水缸设计定制，珊瑚造景，系统维护','专业海水缸定制服务，包括系统设计、设备选型、珊瑚造景、后期维护等全套服务。','浙江省','杭州','西湖区','西湖区文二路海外海大厦',NULL,NULL,2000.00,'起','陈师傅','13800138004',NULL,NULL,'[\"https://picsum.photos/400/300?random=3003\", \"https://picsum.photos/400/300?random=3004\"]','[\"海水缸\", \"珊瑚\", \"定制服务\"]',1,0,234,19,6,'2025-09-14 13:19:02','2025-09-14 13:19:02'),(5,1,'door_service','宠物上门洗澡美容服务','专业宠物美容师上门服务，让您的爱宠在家享受专业护理','我们提供专业的宠物上门洗澡美容服务，美容师经验丰富，设备齐全，让您的爱宠在熟悉的环境中享受专业护理。','北京市','北京','海淀区','服务范围：五环内',NULL,NULL,80.00,'次','美容师小李','13800138005',NULL,NULL,'[\"https://picsum.photos/400/300?random=4001\", \"https://picsum.photos/400/300?random=4002\"]','[\"上门服务\", \"宠物美容\", \"专业\"]',1,0,567,45,18,'2025-09-14 13:19:02','2025-09-14 13:19:02'),(6,1,'door_service','宠物上门训练服务','专业训犬师上门训练，纠正行为问题，建立良好习惯','专业训犬师提供上门训练服务，包括基础服从训练、行为纠正、社会化训练等。','上海市','上海','徐汇区','服务范围：内环内',NULL,NULL,150.00,'次','训犬师老王','13800138006',NULL,NULL,'[\"https://picsum.photos/400/300?random=4003\", \"https://picsum.photos/400/300?random=4004\"]','[\"上门训练\", \"行为纠正\", \"专业训犬师\"]',1,0,432,38,14,'2025-09-14 13:19:02','2025-09-14 13:19:02');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `service_type` int NOT NULL COMMENT '1:上门服务,2:宠物交流,3:鱼缸造景',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_info` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_local_services_provider_id` (`provider_id`),
  KEY `ix_local_services_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logistics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `tracking_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logistics_company` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_logistics_tracking_number` (`tracking_number`),
  KEY `ix_logistics_id` (`id`),
  KEY `ix_logistics_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `max_daily_draws` int DEFAULT NULL COMMENT '每日最大抽奖次数',
  `cost_per_draw` int DEFAULT NULL COMMENT '每次抽奖消耗钻石数',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '抽奖是否开启',
  `start_time` datetime DEFAULT NULL COMMENT '活动开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '活动结束时间',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '活动描述',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_lottery_config_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `lottery_config` VALUES (1,3,0,1,NULL,NULL,'钻石抽奖，每日免费3次机会！','2025-09-20 10:11:03','2025-09-20 10:11:03');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_prizes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '奖品名称',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '奖品类型: voucher/coupon/pet',
  `value` float DEFAULT NULL COMMENT '奖品价值（元）',
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '奖品图标',
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '转盘显示颜色',
  `probability` float NOT NULL COMMENT '中奖概率(0-1)',
  `stock` int DEFAULT NULL COMMENT '库存数量，-1表示无限',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '奖品描述',
  `sort_order` int DEFAULT NULL COMMENT '排序',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_lottery_prizes_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `lottery_prizes` VALUES (1,'1元抵用券','voucher',1,NULL,'#FFE4E1',0.25,-1,1,NULL,1,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(2,'2元抵用券','voucher',2,NULL,'#FFB6C1',0.2,-1,1,NULL,2,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(3,'3元抵用券','voucher',3,NULL,'#FFA07A',0.15,-1,1,NULL,3,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(4,'9.9元抵用券','voucher',9.9,NULL,'#FF7F50',0.12,-1,1,NULL,4,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(5,'12元抵用券','voucher',12,NULL,'#FF6347',0.1,-1,1,NULL,5,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(6,'15元抵用券','voucher',15,NULL,'#FF4500',0.08,-1,1,NULL,6,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(7,'90元优惠券','coupon',90,NULL,'#DC143C',0.05,-1,1,NULL,7,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(8,'128元优惠券','coupon',128,NULL,'#B22222',0.03,-1,1,NULL,8,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(9,'鹦鹉一只','pet',300,NULL,'#228B22',0.015,10,1,NULL,9,'2025-09-20 10:11:03','2025-09-20 10:11:03'),(10,'仓鼠一只','pet',80,NULL,'#32CD32',0.005,5,1,NULL,10,'2025-09-20 10:11:03','2025-09-20 10:11:03');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `prize_id` int DEFAULT NULL,
  `prize_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '中奖奖品名称',
  `prize_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '奖品类型',
  `prize_value` float DEFAULT NULL COMMENT '奖品价值',
  `is_claimed` tinyint(1) DEFAULT NULL COMMENT '是否已领取',
  `claimed_at` datetime DEFAULT NULL COMMENT '领取时间',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '抽奖IP',
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户代理',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `prize_id` (`prize_id`),
  KEY `ix_lottery_records_id` (`id`),
  CONSTRAINT `lottery_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `lottery_records_ibfk_2` FOREIGN KEY (`prize_id`) REFERENCES `lottery_prizes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `lottery_records` VALUES (1,2,1,'1元抵用券','voucher',1,0,NULL,'112.232.17.116','Dart/3.7 (dart:io)','2025-09-20 10:15:44');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板代码',
  `template_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `title_template` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题模板',
  `content_template` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容模板',
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知类型',
  `variables` json DEFAULT NULL COMMENT '模板变量说明',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否激活',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_code` (`template_code`),
  KEY `ix_message_templates_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int DEFAULT NULL,
  `receiver_id` int NOT NULL,
  `message_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_id` int DEFAULT NULL COMMENT '关联的商品或订单ID',
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `conversation_id` int DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_messages_receiver_id` (`receiver_id`),
  KEY `ix_messages_sender_id` (`sender_id`),
  KEY `ix_messages_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `messages` VALUES (1,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：测试咨询消息',2,1,'2025-09-14 12:11:11',1,0,'2025-09-14 12:16:34'),(2,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：支持什么付款方式？',2,1,'2025-09-14 12:11:11',1,0,'2025-09-14 12:16:34'),(3,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：测试咨询消息',2,1,'2025-09-14 12:12:39',1,0,'2025-09-14 12:16:34'),(4,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：API测试咨询消息',2,1,'2025-09-14 12:12:56',1,0,'2025-09-14 12:16:34'),(5,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：什么时候可以发货？',2,1,'2025-09-14 12:16:34',1,0,'2025-09-14 12:16:34'),(6,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：支持什么付款方式？',2,1,'2025-09-14 12:19:11',1,0,'2025-09-14 12:19:11'),(7,2,2,'1',NULL,'刚刚',NULL,1,'2025-09-14 12:19:16',1,0,'2025-09-14 14:36:59'),(8,1,2,'text',NULL,'你好，这个宠物还在吗？',NULL,1,'2025-09-14 07:26:11',4,0,'2025-09-14 14:26:10'),(9,2,1,'text',NULL,'在的，您感兴趣的话可以来看看',NULL,1,'2025-09-14 03:26:11',4,0,'2025-09-14 14:26:10'),(10,1,2,'text',NULL,'好的，什么时候方便？',NULL,1,'2025-09-14 13:26:11',4,0,'2025-09-14 14:26:10'),(11,2,1,'text',NULL,'明天下午怎么样？',NULL,0,'2025-09-14 13:26:11',4,0,'2025-09-14 14:26:10'),(12,1,2,'text',NULL,'可以的，地址发给我一下',NULL,1,'2025-09-14 09:26:11',4,0,'2025-09-14 14:26:10'),(13,1,3,'text',NULL,'你好，这个宠物还在吗？',NULL,1,'2025-09-14 06:26:11',5,0,'2025-09-14 14:26:10'),(14,3,1,'text',NULL,'在的，您感兴趣的话可以来看看',NULL,1,'2025-09-14 14:26:11',5,0,'2025-09-14 14:26:10'),(15,1,3,'text',NULL,'好的，什么时候方便？',NULL,1,'2025-09-14 08:26:11',5,0,'2025-09-14 14:26:10'),(16,2,3,'text',NULL,'你好，这个宠物还在吗？',NULL,1,'2025-09-14 06:26:11',6,0,'2025-09-14 14:26:10'),(17,3,2,'text',NULL,'在的，您感兴趣的话可以来看看',NULL,1,'2025-09-14 05:26:11',6,0,'2025-09-14 14:26:10'),(18,2,3,'text',NULL,'好的，什么时候方便？',NULL,0,'2025-09-14 05:26:11',6,0,'2025-09-14 14:26:10'),(19,3,2,'text',NULL,'明天下午怎么样？',NULL,1,'2025-09-14 08:26:11',6,0,'2025-09-14 14:26:10'),(20,2,3,'text',NULL,'可以的，地址发给我一下',NULL,1,'2025-09-14 05:26:11',6,0,'2025-09-14 14:26:10'),(21,3,2,'text',NULL,'好的，稍等我发给您',NULL,1,'2025-09-14 04:26:11',6,0,'2025-09-14 14:36:55'),(22,2,2,'3',NULL,'我对您的商品感兴趣，想了解一下：什么时候可以发货？',1,1,'2025-09-14 18:48:13',1,0,'2025-09-14 18:48:13'),(23,2,13,'3',NULL,'我对您的商品感兴趣，想了解一下：什么时候可以发货？',12,0,'2025-09-19 22:19:52',7,0,'2025-09-19 22:19:52'),(24,14,2,'3',NULL,'我对您的商品感兴趣，想了解一下：什么时候可以发货？',3,0,'2025-09-28 14:35:48',8,0,'2025-09-28 14:35:48'),(25,14,2,'3',NULL,'我对您的商品感兴趣，想了解一下：什么时候可以发货？',3,0,'2025-09-28 14:36:18',8,0,'2025-09-28 14:36:18'),(26,14,2,'1',NULL,'你好',NULL,0,'2025-09-28 14:36:22',8,0,'2025-09-28 14:36:22');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nearby_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float DEFAULT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_wechat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `like_count` int DEFAULT NULL,
  `is_top` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_nearby_items_id` (`id`),
  CONSTRAINT `nearby_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `nearby_items` VALUES (1,1,'纯种拉布拉多幼犬出售','2个月大的拉布拉多幼犬，疫苗齐全，品相好，寻找爱心家庭','宠物',3500,'[\"/static/uploads/labrador_puppy.jpg\"]','北京市朝阳区',39.9951,116.472,'138****5678','lab_breeder',89,23,1,'ACTIVE','2025-09-19 11:34:55',NULL),(2,2,'猫砂盆转让','全自动智能猫砂盆，9成新，原价1200现价600转让','用品',600,'[\"/static/uploads/litter_box.jpg\"]','上海市浦东新区',31.2304,121.474,'139****1234',NULL,45,8,0,'ACTIVE','2025-09-19 11:34:55',NULL),(3,3,'进口狗粮批发','各品牌进口狗粮批发，量大从优，支持同城配送','食品',280,'[\"/static/uploads/dog_food.jpg\"]','广州市天河区',23.1291,113.264,'187****5432',NULL,156,34,0,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `product_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_order_items_order_id` (`order_id`),
  KEY `ix_order_items_id` (`id`),
  KEY `ix_order_items_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `order_items` VALUES (1,6,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 16:50:31'),(2,7,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 16:54:16'),(3,8,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 16:54:19'),(4,9,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 16:56:19'),(5,10,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 16:58:30'),(6,11,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:00:26'),(7,12,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:07:05'),(8,13,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:10:28'),(9,14,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:11:10'),(10,15,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:13:31'),(11,16,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:14:59'),(12,17,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:17:05'),(13,18,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:26:27'),(14,19,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:27:30'),(15,20,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:31:51'),(16,21,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:39:44'),(17,22,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:48:17'),(18,23,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:49:35'),(19,24,1,'宠物商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:52:47'),(20,25,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:54:05'),(21,26,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:54:20'),(22,27,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 17:55:19'),(23,28,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 18:33:07'),(24,29,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-13 18:35:08'),(25,30,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-14 00:44:35'),(26,31,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-14 18:33:05'),(27,32,1,'测试商品1 - 待付款','https://picsum.photos/200/200?random=1',1,109.99,109.99,'2025-09-15 12:00:37'),(28,33,2,'测试商品2 - 待发货','https://picsum.photos/200/200?random=2',1,119.99,119.99,'2025-09-15 12:00:37'),(29,34,3,'测试商品3 - 待收货','https://picsum.photos/200/200?random=3',1,129.99,129.99,'2025-09-15 12:00:37'),(30,35,4,'测试商品4 - 已完成','https://picsum.photos/200/200?random=4',1,139.99,139.99,'2025-09-15 12:00:37'),(31,36,5,'测试商品5 - 已取消','https://picsum.photos/200/200?random=5',1,149.99,149.99,'2025-09-15 12:00:37'),(32,37,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-19 18:54:56'),(33,38,1,'测试商品','https://picsum.photos/200/200?random=1',1,0.01,0.01,'2025-09-27 13:27:25');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buyer_id` int NOT NULL,
  `seller_id` int NOT NULL,
  `product_id` int NOT NULL,
  `final_price` decimal(10,2) NOT NULL,
  `shipping_fee` decimal(8,2) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` int DEFAULT NULL COMMENT '1:支付宝,2:微信,3:银行卡',
  `payment_status` int DEFAULT NULL COMMENT '1:待支付,2:已支付,3:已退款',
  `order_status` int DEFAULT NULL COMMENT '1:待支付,2:待发货,3:已发货,4:已收货,5:已完成,6:已取消',
  `shipping_address` json DEFAULT NULL COMMENT '收货地址信息',
  `tracking_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_orders_order_no` (`order_no`),
  KEY `ix_orders_buyer_id` (`buyer_id`),
  KEY `ix_orders_id` (`id`),
  KEY `ix_orders_seller_id` (`seller_id`),
  KEY `ix_orders_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `orders` VALUES (1,'TEST20250913162530213043',2,2,1,0.01,0.00,0.01,1,1,1,'{\"notes\": null, \"shipping_address\": \"说到底 厄尔\"}',NULL,NULL,NULL,NULL,'2025-09-13 16:25:30','2025-09-19 16:44:27'),(2,'TEST20250913162814110643',2,2,1,0.01,0.00,0.01,1,1,1,'{\"name\": \"测试用户\", \"phone\": \"13800138000\", \"address\": \"测试地址\"}',NULL,NULL,NULL,NULL,'2025-09-13 16:28:14','2025-09-13 16:28:14'),(3,'TEST20250913162918675080',2,2,1,0.01,0.00,0.01,1,1,1,'{\"name\": \"测试用户\", \"phone\": \"13800138000\", \"address\": \"测试地址\"}',NULL,NULL,NULL,NULL,'2025-09-13 16:29:18','2025-09-13 16:29:18'),(4,'TEST20250913163137260898',2,2,1,0.01,0.00,0.01,1,1,1,'{\"name\": \"测试用户\", \"phone\": \"13800138000\", \"address\": \"测试地址\"}',NULL,NULL,NULL,NULL,'2025-09-13 16:31:37','2025-09-13 16:31:37'),(5,'TEST20250913163654624807',2,2,1,0.01,0.00,0.01,1,1,1,'{\"name\": \"测试用户\", \"phone\": \"13800138000\", \"address\": \"测试地址\"}',NULL,NULL,NULL,NULL,'2025-09-13 16:36:54','2025-09-13 16:36:54'),(6,'TEST_1757753431',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 16:50:31','2025-09-13 16:50:31'),(7,'TEST_1757753656',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 16:54:16','2025-09-13 16:54:16'),(8,'TEST_1757753659',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 16:54:19','2025-09-13 16:54:19'),(9,'TEST_1757753779',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 16:56:19','2025-09-13 16:56:19'),(10,'TEST_1757753910',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 16:58:30','2025-09-13 16:58:30'),(11,'TEST_1757754026',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:00:26','2025-09-13 17:00:26'),(12,'TEST_1757754425',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:07:05','2025-09-13 17:07:05'),(13,'TEST_1757754628',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:10:28','2025-09-13 17:10:28'),(14,'TEST_1757754670',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:11:10','2025-09-13 17:11:10'),(15,'TEST_1757754811',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:13:31','2025-09-13 17:13:31'),(16,'TEST_1757754899',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:14:59','2025-09-13 17:14:59'),(17,'TEST_1757755025',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:17:05','2025-09-13 17:17:05'),(18,'TEST_1757755587',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:26:27','2025-09-13 17:26:27'),(19,'TEST_1757755650',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:27:30','2025-09-13 17:27:30'),(20,'TEST_1757755911',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:31:51','2025-09-13 17:31:51'),(21,'TEST_1757756384',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:39:44','2025-09-13 17:39:44'),(22,'TEST_1757756897',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:48:17','2025-09-13 17:48:17'),(23,'TEST_1757756975',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:49:35','2025-09-13 17:49:35'),(24,'TEST_1757757167',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:52:47','2025-09-13 17:52:47'),(25,'TEST_1757757245',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:54:05','2025-09-13 17:54:05'),(26,'TEST_1757757260',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:54:20','2025-09-13 17:54:20'),(27,'TEST_1757757319',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 17:55:19','2025-09-13 17:55:19'),(28,'TEST_1757759587',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 18:33:07','2025-09-13 18:33:07'),(29,'TEST_1757759708',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-13 18:35:08','2025-09-13 18:35:08'),(30,'TEST_1757781875',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-14 00:44:35','2025-09-14 00:44:35'),(31,'TEST_1757845985',10,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-14 18:33:05','2025-09-14 18:33:05'),(32,'PET2025091512003718131',2,1,1,109.99,10.00,119.99,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-15 12:00:37','2025-09-15 12:00:37'),(33,'PET2025091512003730382',2,1,2,119.99,10.00,129.99,1,2,2,'{\"notes\": null, \"shipping_address\": \"还社会实践 技术监督局\"}',NULL,NULL,NULL,NULL,'2025-09-15 12:00:37','2025-09-19 16:27:01'),(34,'PET2025091512003727993',2,1,3,129.99,10.00,139.99,1,2,3,NULL,NULL,NULL,NULL,NULL,'2025-09-15 12:00:37','2025-09-15 12:00:37'),(35,'PET2025091512003731834',2,1,4,139.99,10.00,149.99,1,2,4,NULL,NULL,NULL,NULL,NULL,'2025-09-15 12:00:37','2025-09-15 12:00:37'),(36,'PET2025091512003743755',2,1,5,149.99,10.00,159.99,1,3,6,NULL,NULL,NULL,NULL,NULL,'2025-09-15 12:00:37','2025-09-15 12:00:37'),(37,'TEST_1758279296',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-19 18:54:56','2025-09-19 18:54:56'),(38,'TEST_1758950845',2,1,1,0.01,0.00,0.01,1,1,1,NULL,NULL,NULL,NULL,NULL,'2025-09-27 13:27:25','2025-09-27 13:27:25');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partner_applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_remark` text COLLATE utf8mb4_unicode_ci,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `ix_partner_applications_id` (`id`),
  CONSTRAINT `partner_applications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `partner_applications_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `user_id` int NOT NULL,
  `payment_method` int NOT NULL COMMENT '1:支付宝,2:微信,3:银行卡',
  `amount` decimal(10,2) NOT NULL,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'payment:支付, refund:退款',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pending:待支付, paid:已支付, failed:失败, refunded:已退款',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `ix_payments_id` (`id`),
  KEY `ix_payments_user_id` (`user_id`),
  KEY `ix_payments_order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `payments` VALUES (1,1,2,1,0.01,'ORDER_1_20250913162536','payment','pending','2025-09-13 16:25:36','2025-09-13 16:25:36'),(2,2,2,1,0.01,'ORDER_2_20250913162815','payment','pending','2025-09-13 16:28:15','2025-09-13 16:28:15'),(3,2,2,1,0.01,'ORDER_2_20250913162915','payment','pending','2025-09-13 16:29:15','2025-09-13 16:29:15'),(4,3,2,1,0.01,'ORDER_3_20250913162920','payment','pending','2025-09-13 16:29:20','2025-09-13 16:29:20'),(5,3,2,1,0.01,'ORDER_3_20250913162943','payment','pending','2025-09-13 16:29:43','2025-09-13 16:29:43'),(6,3,2,1,0.01,'ORDER_3_20250913162947','payment','pending','2025-09-13 16:29:47','2025-09-13 16:29:47'),(7,4,2,1,0.01,'ORDER_4_20250913163138','payment','pending','2025-09-13 16:31:38','2025-09-13 16:31:38'),(8,4,2,1,0.01,'ORDER_4_20250913163650','payment','pending','2025-09-13 16:36:50','2025-09-13 16:36:50'),(9,5,2,1,0.01,'ORDER_5_20250913163656','payment','pending','2025-09-13 16:36:56','2025-09-13 16:36:56'),(10,5,2,1,0.01,'ORDER_5_20250913163934','payment','pending','2025-09-13 16:39:34','2025-09-13 16:39:34'),(11,1,2,1,0.01,'ORDER_1_20250913164143','payment','pending','2025-09-13 16:41:43','2025-09-13 16:41:43'),(12,1,2,1,0.01,'TEST_1_1757753246','payment','pending','2025-09-13 16:47:26','2025-09-13 16:47:26'),(13,1,2,1,0.01,'TEST_1_1757753272','payment','pending','2025-09-13 16:47:52','2025-09-13 16:47:52'),(14,1,2,1,0.01,'TEST_1_1757753328','payment','pending','2025-09-13 16:48:48','2025-09-13 16:48:48'),(15,1,2,1,0.01,'TEST_1_1757753348','payment','pending','2025-09-13 16:49:08','2025-09-13 16:49:08'),(16,1,2,1,0.01,'TEST_1_1757753366','payment','pending','2025-09-13 16:49:26','2025-09-13 16:49:26'),(17,1,2,1,0.01,'TEST_1_1757753372','payment','pending','2025-09-13 16:49:32','2025-09-13 16:49:32'),(18,6,2,1,0.01,'TEST_6_1757753434','payment','pending','2025-09-13 16:50:34','2025-09-13 16:50:34'),(19,6,2,1,0.01,'TEST_6_1757753447','payment','pending','2025-09-13 16:50:47','2025-09-13 16:50:47'),(20,6,2,1,0.01,'ORDER_6_20250913165412','payment','pending','2025-09-13 16:54:12','2025-09-13 16:54:12'),(21,6,2,1,0.01,'ORDER_6_20250913165415','payment','pending','2025-09-13 16:54:15','2025-09-13 16:54:15'),(22,8,2,1,0.01,'ORDER_8_20250913165420','payment','pending','2025-09-13 16:54:20','2025-09-13 16:54:20'),(23,9,2,1,0.01,'ORDER_9_20250913165621','payment','pending','2025-09-13 16:56:21','2025-09-13 16:56:21'),(24,10,2,1,0.01,'ORDER_10_20250913165831','payment','pending','2025-09-13 16:58:31','2025-09-13 16:58:31'),(25,11,2,1,0.01,'ORDER_11_20250913170028','payment','pending','2025-09-13 17:00:28','2025-09-13 17:00:28'),(26,12,2,1,0.01,'ORDER_12_20250913170707','payment','pending','2025-09-13 17:07:07','2025-09-13 17:07:07'),(27,13,2,1,0.01,'ORDER_13_20250913171030','payment','pending','2025-09-13 17:10:30','2025-09-13 17:10:30'),(28,14,2,1,0.01,'ORDER_14_20250913171111','payment','pending','2025-09-13 17:11:11','2025-09-13 17:11:11'),(29,15,2,1,0.01,'ORDER_15_20250913171332','payment','pending','2025-09-13 17:13:32','2025-09-13 17:13:32'),(30,16,2,1,0.01,'ORDER_16_20250913171500','payment','pending','2025-09-13 17:15:00','2025-09-13 17:15:00'),(31,17,2,1,0.01,'ORDER_17_20250913171706','payment','pending','2025-09-13 17:17:06','2025-09-13 17:17:06'),(32,17,2,1,0.01,'ORDER_17_20250913172613','payment','pending','2025-09-13 17:26:13','2025-09-13 17:26:13'),(33,18,2,1,0.01,'ORDER_18_20250913172629','payment','pending','2025-09-13 17:26:29','2025-09-13 17:26:29'),(34,19,2,1,0.01,'ORDER_19_20250913172733','payment','pending','2025-09-13 17:27:33','2025-09-13 17:27:33'),(35,19,2,1,0.01,'ORDER_19_20250913173005','payment','pending','2025-09-13 17:30:05','2025-09-13 17:30:05'),(36,20,2,1,0.01,'ORDER_20_20250913173153','payment','pending','2025-09-13 17:31:53','2025-09-13 17:31:53'),(37,21,2,1,0.01,'ORDER_21_20250913173946','payment','pending','2025-09-13 17:39:46','2025-09-13 17:39:46'),(38,21,2,1,0.01,'ORDER_21_20250913174003','payment','pending','2025-09-13 17:40:03','2025-09-13 17:40:03'),(39,22,2,1,0.01,'ORDER_22_20250913174818','payment','pending','2025-09-13 17:48:18','2025-09-13 17:48:18'),(40,23,2,1,0.01,'ORDER_23_20250913174936','payment','pending','2025-09-13 17:49:36','2025-09-13 17:49:36'),(41,24,2,1,0.01,'ORDER_24_20250913175249','payment','pending','2025-09-13 17:52:49','2025-09-13 17:52:49'),(42,24,2,1,0.01,'ORDER_24_20250913175256','payment','pending','2025-09-13 17:52:56','2025-09-13 17:52:56'),(43,25,2,1,0.01,'ORDER_25_20250913175406','payment','pending','2025-09-13 17:54:06','2025-09-13 17:54:06'),(44,26,2,1,0.01,'ORDER_26_20250913175422','payment','pending','2025-09-13 17:54:22','2025-09-13 17:54:22'),(45,27,2,1,0.01,'ORDER_27_20250913175521','payment','pending','2025-09-13 17:55:21','2025-09-13 17:55:21'),(46,27,2,1,0.01,'ORDER_27_20250913183302','payment','pending','2025-09-13 18:33:02','2025-09-13 18:33:02'),(47,29,2,1,0.01,'ORDER_29_20250913183509','payment','pending','2025-09-13 18:35:09','2025-09-13 18:35:09'),(48,29,2,1,0.01,'ORDER_29_20250913190907','payment','pending','2025-09-13 19:09:07','2025-09-13 19:09:07'),(49,30,2,1,0.01,'ORDER_30_20250914004437','payment','pending','2025-09-14 00:44:37','2025-09-14 00:44:37'),(50,1,2,1,0.01,'ORDER_1_20250914140234','payment','pending','2025-09-14 14:02:34','2025-09-14 14:02:34'),(51,31,10,1,0.01,'ORDER_31_20250914183306','payment','pending','2025-09-14 18:33:06','2025-09-14 18:33:06'),(52,1,2,1,0.01,'ORDER_1_20250914190828','payment','pending','2025-09-14 19:08:28','2025-09-14 19:08:28'),(53,1,2,1,0.01,'ORDER_1_20250919162924','payment','pending','2025-09-19 16:29:24','2025-09-19 16:29:24'),(54,1,2,1,0.01,'ORDER_1_20250919162959','payment','pending','2025-09-19 16:29:59','2025-09-19 16:29:59'),(55,10,2,1,0.01,'ORDER_10_20250919183947','payment','pending','2025-09-19 18:39:47','2025-09-19 18:39:47'),(56,37,2,1,0.01,'ORDER_37_20250919185458','payment','pending','2025-09-19 18:54:58','2025-09-19 18:54:58'),(57,37,2,1,0.01,'ORDER_37_20250919185513','payment','pending','2025-09-19 18:55:13','2025-09-19 18:55:13'),(58,37,2,1,0.01,'ORDER_37_20250919221617','payment','pending','2025-09-19 22:16:17','2025-09-19 22:16:17'),(59,38,2,1,0.01,'ORDER_38_20250927132726','payment','pending','2025-09-27 13:27:26','2025-09-27 13:27:26');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_breed_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '宠物类型',
  `breed_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '品种标识',
  `breed_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '品种名称',
  `breed_name_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '英文名称',
  `characteristics` json DEFAULT NULL COMMENT '特征列表',
  `physical_traits` json DEFAULT NULL COMMENT '外观特征',
  `temperament` json DEFAULT NULL COMMENT '性格特点',
  `care_tips` json DEFAULT NULL COMMENT '护理建议',
  `health_tips` json DEFAULT NULL COMMENT '健康提示',
  `feeding_guide` json DEFAULT NULL COMMENT '喂养指南',
  `exercise_needs` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '运动需求: low(低), medium(中), high(高)',
  `price_min` decimal(10,2) DEFAULT NULL COMMENT '最低价格',
  `price_max` decimal(10,2) DEFAULT NULL COMMENT '最高价格',
  `price_currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '货币单位',
  `popularity_score` decimal(3,2) DEFAULT NULL COMMENT '流行度评分(0-1)',
  `recognition_count` int DEFAULT NULL COMMENT '被识别次数',
  `origin_country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原产国',
  `life_span` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '寿命范围',
  `size_category` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '体型分类: small(小型), medium(中型), large(大型)',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `is_verified` tinyint(1) DEFAULT NULL COMMENT '是否已验证',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_pet_breed_info_id` (`id`),
  KEY `ix_pet_breed_info_pet_type` (`pet_type`),
  KEY `ix_pet_breed_info_breed_key` (`breed_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_breeding_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `pet_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `breed` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int NOT NULL,
  `weight` float DEFAULT NULL,
  `health_status` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vaccination_status` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `requirements` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_wechat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_pet_breeding_info_id` (`id`),
  CONSTRAINT `pet_breeding_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `pet_breeding_info` VALUES (1,1,'球球','狗','金毛','公',24,30.5,'健康，疫苗齐全','已完成全部疫苗接种','[\"/static/uploads/golden_male.jpg\"]','纯种金毛，品相优良，性格温顺，已获得多项比赛奖项','希望找到同样优秀的母犬配种','北京市朝阳区','138****5678','golden_lover',2000,1,'ACTIVE','2025-09-19 11:34:55',NULL),(2,2,'小白','猫','英短银渐层','母',18,4.2,'健康','疫苗齐全','[\"/static/uploads/british_female.jpg\"]','纯种英短银渐层，毛色纯正，体型标准','寻找品相好的公猫配种','上海市静安区','139****1234',NULL,1500,1,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_social_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `user_id` (`user_id`),
  KEY `parent_id` (`parent_id`),
  KEY `ix_pet_social_comments_id` (`id`),
  CONSTRAINT `pet_social_comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `pet_social_posts` (`id`),
  CONSTRAINT `pet_social_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `pet_social_comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `pet_social_comments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_social_likes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `post_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `user_id` (`user_id`),
  KEY `ix_pet_social_likes_id` (`id`),
  CONSTRAINT `pet_social_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `pet_social_posts` (`id`),
  CONSTRAINT `pet_social_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_social_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `like_count` int DEFAULT NULL,
  `comment_count` int DEFAULT NULL,
  `is_top` tinyint(1) DEFAULT NULL,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_pet_social_posts_id` (`id`),
  CONSTRAINT `pet_social_posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `pet_social_posts` VALUES (1,1,'我的金毛宝贝成长记录','分享一下我家金毛从幼犬到成犬的成长过程，希望能帮助到其他宠物主人。金毛真的是很聪明很温顺的狗狗，特别适合家庭饲养。','[\"/static/uploads/golden_puppy.jpg\", \"/static/uploads/golden_adult.jpg\"]','狗','北京市朝阳区',156,23,8,1,'ACTIVE','2025-09-19 11:34:55',NULL),(2,2,'猫咪训练小技巧分享','很多人说猫咪不能训练，其实是错误的。我家橘猫现在会坐下、握手、转圈，分享一下训练心得。','[\"/static/uploads/cat_training.jpg\"]','猫','上海市浦东新区',89,15,5,0,'ACTIVE','2025-09-19 11:34:55',NULL),(3,3,'兔子饮食注意事项','养兔子的朋友一定要注意饮食搭配，哪些能吃哪些不能吃，这篇帖子详细介绍。',NULL,'兔子','广州市天河区',67,12,3,0,'ACTIVE','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_valuation_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `breed` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` float DEFAULT NULL,
  `health_status` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `special_features` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `estimated_value` float DEFAULT NULL,
  `valuator_id` int DEFAULT NULL,
  `valuation_notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('PENDING','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `valuator_id` (`valuator_id`),
  KEY `ix_pet_valuation_services_id` (`id`),
  CONSTRAINT `pet_valuation_services_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `pet_valuation_services_ibfk_2` FOREIGN KEY (`valuator_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `pet_valuation_services` VALUES (1,1,'狗','金毛',24,'公',30.5,'健康','血统纯正，获得过比赛奖项','[\"/static/uploads/golden_valuation.jpg\"]',8000,2,'品相优良，血统证书齐全，市场价值较高','COMPLETED','2025-09-19 11:34:55',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_favorites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_product_favorites_product_id` (`product_id`),
  KEY `ix_product_favorites_user_id` (`user_id`),
  KEY `ix_product_favorites_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_product_images_product_id` (`product_id`),
  KEY `ix_product_images_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `seller_id` int NOT NULL,
  `category_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL COMMENT '商品图片数组',
  `starting_price` decimal(10,2) NOT NULL,
  `current_price` decimal(10,2) NOT NULL,
  `buy_now_price` decimal(10,2) DEFAULT NULL COMMENT '一口价',
  `auction_type` int DEFAULT NULL COMMENT '1:拍卖,2:一口价,3:混合',
  `auction_start_time` datetime DEFAULT NULL,
  `auction_end_time` datetime DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_fee` decimal(8,2) DEFAULT NULL,
  `is_free_shipping` tinyint(1) DEFAULT NULL,
  `condition_type` int DEFAULT NULL COMMENT '1:全新,2:二手,3:其他',
  `stock_quantity` int DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `bid_count` int DEFAULT NULL,
  `favorite_count` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1:待审核,2:拍卖中,3:已结束,4:已下架',
  `is_featured` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `extension_count` int DEFAULT '0',
  `min_bid_increment` decimal(10,2) DEFAULT '1.00',
  PRIMARY KEY (`id`),
  KEY `ix_products_category_id` (`category_id`),
  KEY `ix_products_seller_id` (`seller_id`),
  KEY `ix_products_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `products` VALUES (1,2,1,'纯种英短蓝猫 - 品相优秀','健康活泼的英短蓝猫，疫苗齐全，品相优秀，性格温顺。包健康包纯种，支持上门看猫。','[\"https://picsum.photos/400/400?random=cat1\", \"https://picsum.photos/400/400?random=cat2\"]',800.00,820.00,1500.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',50.00,0,1,1,158,8,23,3,1,'2025-09-13 19:55:57','2025-09-19 18:16:48',0,1.00),(2,2,1,'金毛幼犬 - 疫苗齐全','2个月大金毛幼犬，疫苗已打，驱虫完成。父母都是纯种金毛，小狗活泼健康。','[\"https://picsum.photos/400/400?random=dog1\", \"https://picsum.photos/400/400?random=dog2\"]',600.00,970.00,1200.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','上海市',80.00,0,1,1,90,12,15,2,1,'2025-09-14 11:15:17','2025-09-19 19:19:44',0,1.00),(3,2,2,'泰国斗鱼 - 炫彩品种','精品泰国斗鱼，色彩鲜艳，鱼鳍完整。适合新手饲养，生命力强。','[\"https://picsum.photos/400/400?random=fish1\", \"https://picsum.photos/400/400?random=fish2\"]',50.00,100.00,150.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','广州市',20.00,0,1,1,67,5,18,3,1,'2025-09-13 19:55:57','2025-09-25 13:52:27',0,1.00),(4,2,2,'龙鱼 - 金龙血统','优质金龙鱼，血统纯正，体型完美。适合高端玩家收藏，升值潜力大。','[\"https://picsum.photos/400/400?random=dragon1\", \"https://picsum.photos/400/400?random=dragon2\"]',2000.00,3200.00,5000.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','深圳市',100.00,0,1,1,234,15,56,3,1,'2025-09-13 19:55:57','2025-09-27 12:10:21',0,1.00),(5,2,3,'智能鱼缸过滤器','智能过滤系统，自动清洁，静音设计。适合各种尺寸鱼缸，简单易用。','[\"https://picsum.photos/400/400?random=filter1\", \"https://picsum.photos/400/400?random=filter2\"]',299.00,810.00,299.00,2,'2025-09-19 16:56:42','2025-09-21 17:56:42','杭州市',0.00,1,1,50,123,0,34,3,0,'2025-09-13 19:55:57','2025-09-19 18:17:33',0,1.00),(6,2,1,'猫咪玩具套装','精选猫咪玩具10件套，包含逗猫棒、小老鼠、毛球等。安全材质，增进与猫咪的互动。','[\"https://picsum.photos/400/400?random=toy1\", \"https://picsum.photos/400/400?random=toy2\"]',89.00,89.00,89.00,2,'2025-09-19 16:56:42','2025-09-21 17:56:42','成都市',0.00,1,1,200,78,0,12,3,0,'2025-09-13 19:55:57','2025-09-28 14:38:40',0,1.00),(7,2,1,'测试商品 - 金毛幼犬','测试用的金毛幼犬商品','[\"https://picsum.photos/400/400?random=dog1\"]',600.00,750.00,NULL,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','上海市',0.00,0,1,1,0,0,0,2,0,'2025-09-14 11:11:47','2025-09-19 17:56:42',0,1.00),(8,2,1,'纯种英短蓝猫 - 品相优秀','健康活泼的英短蓝猫，疫苗齐全，品相优秀，性格温顺。包健康包纯种，支持上门看猫。','[\"https://picsum.photos/400/400?random=cat1\", \"https://picsum.photos/400/400?random=cat2\"]',800.00,1200.00,NULL,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',0.00,0,1,1,0,0,0,2,0,'2025-09-14 11:12:03','2025-09-19 17:56:42',0,1.00),(9,1,2,'泰国斗鱼 - 炫彩品种','精品泰国斗鱼，色彩鲜艳，鱼鳍完整。适合新手饲养，生命力强。','[\"https://picsum.photos/400/400?random=fish1\"]',50.00,80.00,NULL,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','广州市',0.00,0,1,1,0,0,0,2,0,'2025-09-14 11:12:03','2025-09-19 17:56:42',0,1.00),(10,13,1,'可爱小猫咪1号','非常可爱的小猫咪，健康活泼',NULL,100.00,120.00,200.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',10.00,0,1,1,0,0,0,2,0,'2025-09-19 17:50:54','2025-09-19 19:19:35',0,1.00),(11,13,1,'金毛幼犬','纯种金毛幼犬，疫苗齐全',NULL,500.00,520.00,1000.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',10.00,0,1,1,0,0,0,2,0,'2025-09-19 17:50:54','2025-09-19 19:26:42',0,1.00),(12,13,1,'波斯猫成年','美丽的波斯猫，性格温顺',NULL,300.00,370.00,700.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',10.00,0,1,1,0,0,0,2,0,'2025-09-19 17:50:54','2025-09-19 22:19:46',0,1.00),(13,13,1,'哈士奇幼犬','活泼可爱的哈士奇，蓝眼睛',NULL,800.00,800.00,1600.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',10.00,0,1,1,0,0,0,2,0,'2025-09-19 17:50:54','2025-09-19 17:56:42',0,1.00),(14,13,1,'英短蓝猫','纯种英短蓝猫，性格温顺',NULL,600.00,650.00,1300.00,1,'2025-09-19 16:56:42','2025-09-21 17:56:42','北京市',10.00,0,1,1,0,0,0,2,0,'2025-09-19 17:50:54','2025-09-19 17:56:42',0,1.00);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recognition_cache` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片哈希值',
  `pet_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `breed` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confidence` decimal(5,4) NOT NULL,
  `result_data` json DEFAULT NULL COMMENT '完整结果数据',
  `hit_count` int DEFAULT NULL COMMENT '命中次数',
  `last_accessed` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '最后访问时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_recognition_cache_image_hash` (`image_hash`),
  KEY `ix_recognition_cache_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycling_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_price` float DEFAULT NULL,
  `recycling_price` float DEFAULT NULL,
  `condition` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_wechat` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_recycling_items_id` (`id`),
  CONSTRAINT `recycling_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recycling_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `buyer_id` int NOT NULL,
  `seller_id` int NOT NULL,
  `agreed_price` float NOT NULL,
  `pickup_address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pickup_time` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `buyer_id` (`buyer_id`),
  KEY `seller_id` (`seller_id`),
  KEY `ix_recycling_orders_id` (`id`),
  CONSTRAINT `recycling_orders_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `recycling_items` (`id`),
  CONSTRAINT `recycling_orders_ibfk_2` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`),
  CONSTRAINT `recycling_orders_ibfk_3` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `keyword` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `search_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'product, store',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_search_history_user_id` (`user_id`),
  KEY `ix_search_history_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shops` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner_id` int NOT NULL,
  `shop_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_logo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `business_license` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `total_sales` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1:正常,2:暂停,3:关闭',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_shops_id` (`id`),
  KEY `ix_shops_owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `shops` VALUES (1,2,'萌宠天堂','https://picsum.photos/100/100?random=shop1','专业宠物繁育基地，提供优质宠物',NULL,'400-123-4567','北京市朝阳区',4.80,158,1,'2025-09-13 19:55:57','2025-09-13 19:55:57'),(2,2,'水族世界','https://picsum.photos/100/100?random=shop2','专业水族器材和观赏鱼销售',NULL,'400-987-6543','上海市浦东新区',4.60,89,1,'2025-09-13 19:55:57','2025-09-13 19:55:57');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '手机号',
  `code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '验证码',
  `is_used` tinyint(1) DEFAULT NULL COMMENT '是否已使用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `expires_at` datetime NOT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`),
  KEY `ix_sms_codes_id` (`id`),
  KEY `ix_sms_codes_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `sms_codes` VALUES (6,'13800138001','704847',1,'2025-09-13 21:21:34','2025-09-13 13:26:35'),(13,'18133912602','817279',1,'2025-09-15 12:05:09','2025-09-15 04:10:09'),(14,'19515866951','592007',1,'2025-09-19 17:28:47','2025-09-19 09:33:47'),(17,'18663764585','450333',1,'2025-09-28 19:14:29','2025-09-28 11:19:29'),(18,'18315707060','740236',1,'2025-09-28 23:17:29','2025-09-28 15:22:30'),(19,'18366175208','704651',1,'2025-09-28 23:23:20','2025-09-28 15:28:20');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `special_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `banner_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_special_events_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `special_events` VALUES (1,'新春萌宠专场','新春特惠，精选优质宠物，限时拍卖！','https://picsum.photos/800/400?random=event1','2025-09-12 19:55:58','2025-09-20 19:55:58',1,'2025-09-13 19:55:57','2025-09-13 19:55:57'),(2,'水族精品专场','精品观赏鱼和水族用品，打造完美水族世界','https://picsum.photos/800/400?random=event2','2025-09-13 07:55:00','2025-09-30 19:55:00',1,'2025-09-13 19:55:57','2025-09-19 17:29:59'),(3,'一口价精选','精选优质商品，一口价直接购买，无需等待','https://picsum.photos/800/400?random=event3','2025-09-11 19:55:58','2025-09-23 19:55:58',1,'2025-09-13 19:55:57','2025-09-13 19:55:57'),(4,'测试专场','这是一个测试专场','https://example.com/banner.jpg','2025-09-19 17:50:15','2025-09-26 17:50:15',1,'2025-09-19 17:50:14','2025-09-19 17:50:14');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '申请用户ID',
  `store_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '店铺名称',
  `store_description` text COLLATE utf8mb4_unicode_ci COMMENT '店铺介绍',
  `store_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '店铺类型：个人店、个体商家、企业店、旗舰店',
  `consignee_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '收货人姓名',
  `consignee_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '收货人电话',
  `return_region` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '退货地区',
  `return_address` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '详细地址',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '真实姓名',
  `id_number` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '身份证号',
  `id_start_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '身份证开始日期',
  `id_end_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '身份证结束日期',
  `id_front_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证人像面照片',
  `id_back_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证国徽面照片',
  `business_license_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '营业执照照片',
  `status` int DEFAULT NULL COMMENT '申请状态：0:待审核,1:审核通过,2:审核拒绝,3:已开店',
  `reject_reason` text COLLATE utf8mb4_unicode_ci COMMENT '拒绝原因',
  `reviewer_id` int DEFAULT NULL COMMENT '审核员ID',
  `reviewed_at` datetime DEFAULT NULL COMMENT '审核时间',
  `deposit_amount` decimal(10,2) DEFAULT NULL COMMENT '押金金额',
  `annual_fee` decimal(10,2) DEFAULT NULL COMMENT '年费',
  `payment_status` int DEFAULT NULL COMMENT '支付状态：0:未支付,1:已支付',
  `paid_at` datetime DEFAULT NULL COMMENT '支付时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_store_applications_id` (`id`),
  KEY `ix_store_applications_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `store_applications` VALUES (1,1,'萌宠小屋','专业的宠物用品和宠物服务，为您的爱宠提供最好的照顾。','个人店','张三','13800138001','山东省济南市历下区','经十路123号','张三','370102199001011234','2010-01-01','2030-01-01','/static/uploads/store_applications/demo_id_front.jpg','/static/uploads/store_applications/demo_id_back.jpg',NULL,0,NULL,NULL,NULL,600.00,188.00,0,NULL,'2025-09-14 12:35:18','2025-09-14 12:35:18');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_follows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户ID',
  `store_id` int NOT NULL COMMENT '店铺ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_store_follows_id` (`id`),
  KEY `ix_store_follows_user_id` (`user_id`),
  KEY `ix_store_follows_store_id` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `store_follows` VALUES (3,2,1,'2025-09-20 13:33:38');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户ID',
  `store_id` int NOT NULL COMMENT '店铺ID',
  `order_id` int NOT NULL COMMENT '订单ID',
  `rating` int NOT NULL COMMENT '评分1-5',
  `comment` text COLLATE utf8mb4_unicode_ci COMMENT '评价内容',
  `images` json DEFAULT NULL COMMENT '评价图片',
  `reply` text COLLATE utf8mb4_unicode_ci COMMENT '店主回复',
  `replied_at` datetime DEFAULT NULL COMMENT '回复时间',
  `status` int DEFAULT NULL COMMENT '状态:1:正常,2:隐藏',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_store_reviews_order_id` (`order_id`),
  KEY `ix_store_reviews_id` (`id`),
  KEY `ix_store_reviews_user_id` (`user_id`),
  KEY `ix_store_reviews_store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner_id` int NOT NULL COMMENT '店主用户ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '店铺名称',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '店铺描述',
  `avatar` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '店铺头像',
  `banner` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '店铺横幅',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '店铺地址',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `is_open` tinyint(1) DEFAULT NULL COMMENT '是否营业中',
  `business_hours` json DEFAULT NULL COMMENT '营业时间',
  `announcement` text COLLATE utf8mb4_unicode_ci COMMENT '店铺公告',
  `total_products` int DEFAULT NULL COMMENT '商品总数',
  `total_sales` int DEFAULT NULL COMMENT '总销量',
  `total_revenue` decimal(12,2) DEFAULT NULL COMMENT '总收入',
  `rating` decimal(3,2) DEFAULT NULL COMMENT '店铺评分',
  `rating_count` int DEFAULT NULL COMMENT '评分数量',
  `follower_count` int DEFAULT NULL COMMENT '关注数量',
  `status` int DEFAULT NULL COMMENT '状态:1:正常,2:暂停,3:关闭',
  `verified` tinyint(1) DEFAULT NULL COMMENT '是否认证',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_stores_owner_id` (`owner_id`),
  KEY `ix_stores_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `stores` VALUES (1,2,'招财猫旺财狗的店铺','专注宠物拍卖多年，诚信经营，品质保证！我们提供各种可爱的宠物，包括猫咪、狗狗、水族等。每一只宠物都经过精心照料，健康有保障。欢迎大家来店选购心仪的萌宠！','https://picsum.photos/200/200?random=store1','https://picsum.photos/800/300?random=storebanner1','上海市浦东新区张江高科技园区','021-12345678',1,'{\"friday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"monday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"sunday\": {\"open\": \"10:00\", \"close\": \"17:00\"}, \"tuesday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"saturday\": {\"open\": \"10:00\", \"close\": \"17:00\"}, \"thursday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"wednesday\": {\"open\": \"09:00\", \"close\": \"18:00\"}}','🎉 新春特惠进行中！全场商品9折起，欢迎选购！',6,156,45600.00,4.80,89,268,1,1,'2025-09-14 08:29:38','2025-09-20 13:33:38'),(2,2,'招财猫旺财狗的店铺','专注宠物拍卖多年，诚信经营，品质保证！我们提供各种可爱的宠物，包括猫咪、狗狗、水族等。每一只宠物都经过精心照料，健康有保障。欢迎大家来店选购心仪的萌宠！','https://picsum.photos/200/200?random=store2','https://picsum.photos/800/300?random=storebanner2','上海市浦东新区张江高科技园区','021-12345678',1,'{\"friday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"monday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"sunday\": {\"open\": \"10:00\", \"close\": \"17:00\"}, \"tuesday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"saturday\": {\"open\": \"10:00\", \"close\": \"17:00\"}, \"thursday\": {\"open\": \"09:00\", \"close\": \"18:00\"}, \"wednesday\": {\"open\": \"09:00\", \"close\": \"18:00\"}}','🎉 新春特惠进行中！全场商品9折起，欢迎选购！',6,156,45600.00,4.80,89,267,1,1,'2025-03-18 09:11:53','2025-09-14 09:11:52'),(3,3,'名猫馆精品猫舍','专业繁育布偶猫、波斯猫等名贵品种，拥有多个冠军血统种公种母。我们的猫咪都有专业的血统证书，品相优秀，性格温顺，适合家庭饲养。','https://picsum.photos/200/200?random=store3','https://picsum.photos/800/300?random=storebanner3','广州市天河区珠江新城','020-87654321',1,'{\"friday\": {\"open\": \"10:00\", \"close\": \"19:00\"}, \"monday\": {\"open\": \"10:00\", \"close\": \"19:00\"}, \"sunday\": {\"open\": \"09:00\", \"close\": \"20:00\"}, \"tuesday\": {\"open\": \"10:00\", \"close\": \"19:00\"}, \"saturday\": {\"open\": \"09:00\", \"close\": \"20:00\"}, \"thursday\": {\"open\": \"10:00\", \"close\": \"19:00\"}, \"wednesday\": {\"open\": \"10:00\", \"close\": \"19:00\"}}','🏆 CFA认证猫舍，冠军血统布偶猫现接受预定！',8,42,89600.00,4.70,38,156,1,1,'2025-01-07 09:11:53','2025-09-14 09:11:52'),(4,4,'萌宠基地犬业','专业犬类繁育基地，主要繁育金毛、拉布拉多、柯基等热门犬种。所有狗狗都有完整的疫苗记录和健康证明，性格经过专业训练师调教，适合家庭饲养。','https://picsum.photos/200/200?random=store4','https://picsum.photos/800/300?random=storebanner4','南京市鼓楼区中山北路','025-66778899',1,'{\"friday\": {\"open\": \"08:30\", \"close\": \"18:30\"}, \"monday\": {\"open\": \"08:30\", \"close\": \"18:30\"}, \"sunday\": {\"open\": \"08:00\", \"close\": \"19:00\"}, \"tuesday\": {\"open\": \"08:30\", \"close\": \"18:30\"}, \"saturday\": {\"open\": \"08:00\", \"close\": \"19:00\"}, \"thursday\": {\"open\": \"08:30\", \"close\": \"18:30\"}, \"wednesday\": {\"open\": \"08:30\", \"close\": \"18:30\"}}','🐕 新到一窝柯基宝宝，小短腿超可爱，欢迎预约！',12,67,34500.00,4.60,54,189,1,1,'2024-10-29 09:11:53','2025-09-14 09:11:52'),(5,5,'白雪公主萨摩耶犬舍','专业繁育萨摩耶犬，有着\'微笑天使\'美誉的萨摩耶是我们的专长。我们的种犬都有优秀血统，小狗毛量丰厚，表情甜美，性格温顺友善。','https://picsum.photos/200/200?random=store5','https://picsum.photos/800/300?random=storebanner5','天津市河西区友谊路','022-23456789',1,'{\"friday\": {\"open\": \"09:30\", \"close\": \"18:00\"}, \"monday\": {\"open\": \"09:30\", \"close\": \"18:00\"}, \"sunday\": {\"open\": \"09:00\", \"close\": \"19:00\"}, \"tuesday\": {\"open\": \"09:30\", \"close\": \"18:00\"}, \"saturday\": {\"open\": \"09:00\", \"close\": \"19:00\"}, \"thursday\": {\"open\": \"09:30\", \"close\": \"18:00\"}, \"wednesday\": {\"open\": \"09:30\", \"close\": \"18:00\"}}','❄️ 微笑天使萨摩耶，毛量超级棒！支持视频看狗！',5,23,28900.00,4.80,27,143,1,1,'2025-05-17 09:11:53','2025-09-14 09:11:52'),(6,1,'手机用户的宠物店','专业宠物店，提供优质宠物和用品','https://picsum.photos/100/100?random=store1','https://picsum.photos/800/300?random=banner1','中国',NULL,1,'\"9:00-21:00\"','欢迎来到我们的店铺！',0,0,0.00,4.50,0,0,1,1,'2025-09-14 11:12:21','2025-09-14 11:12:21');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int DEFAULT NULL,
  `receiver_id` int NOT NULL,
  `message_type` int DEFAULT NULL COMMENT '1:系统消息,2:私信,3:拍卖通知,4:订单通知',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_id` int DEFAULT NULL COMMENT '关联的商品或订单ID',
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_system_messages_receiver_id` (`receiver_id`),
  KEY `ix_system_messages_sender_id` (`sender_id`),
  KEY `ix_system_messages_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知标题',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知内容',
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '通知类型: system, auction, order, payment',
  `target_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标类型: all, user, group',
  `target_ids` json DEFAULT NULL COMMENT '目标用户ID列表，target_type为user时使用',
  `related_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关联类型: product, order, auction',
  `related_id` int DEFAULT NULL COMMENT '关联ID',
  `extra_data` json DEFAULT NULL COMMENT '额外数据',
  `is_active` tinyint(1) DEFAULT NULL COMMENT '是否激活',
  `priority` int DEFAULT NULL COMMENT '优先级，数字越大优先级越高',
  `publish_time` datetime DEFAULT NULL COMMENT '发布时间，为空则立即发布',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_system_notifications_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `system_notifications` VALUES (6,'欢迎使用拍宠有道','欢迎来到拍宠有道！在这里您可以参与宠物拍卖，发现心仪的宠物。','system','all',NULL,NULL,NULL,NULL,1,1,NULL,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(7,'新品上架通知','有新的精品宠物上架了，快来看看吧！限时拍卖，机会难得。','auction','all',NULL,NULL,NULL,NULL,1,2,NULL,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(8,'拍卖即将结束','您关注的拍品即将结束，请抓紧时间出价！','auction','user','[1]',NULL,NULL,NULL,1,3,NULL,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(9,'订单支付提醒','您有一笔订单待支付，请及时完成支付以免订单被取消。','payment','user','[2]',NULL,NULL,NULL,1,2,NULL,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(10,'订单发货通知','您的订单已发货，预计3-5个工作日内送达，请注意查收。','order','user','[1]',NULL,NULL,NULL,1,1,NULL,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `receiver_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail_address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_user_addresses_user_id` (`user_id`),
  KEY `ix_user_addresses_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_checkins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `checkin_date` date NOT NULL,
  `consecutive_days` int DEFAULT NULL,
  `reward_points` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_user_checkins_user_id` (`user_id`),
  KEY `ix_user_checkins_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `user_checkins` VALUES (1,2,'2025-09-20',1,10,'2025-09-20 12:35:10'),(2,9,'2025-09-28',1,10,'2025-09-28 23:24:09');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `follower_id` int NOT NULL,
  `following_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_user_follows_id` (`id`),
  KEY `ix_user_follows_follower_id` (`follower_id`),
  KEY `ix_user_follows_following_id` (`following_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `notification_id` int NOT NULL,
  `is_read` tinyint(1) DEFAULT NULL COMMENT '是否已读',
  `is_deleted` tinyint(1) DEFAULT NULL COMMENT '是否删除',
  `read_time` datetime DEFAULT NULL COMMENT '阅读时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_id` (`notification_id`),
  KEY `ix_user_notifications_id` (`id`),
  KEY `ix_user_notifications_user_id` (`user_id`),
  CONSTRAINT `user_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_notifications_ibfk_2` FOREIGN KEY (`notification_id`) REFERENCES `system_notifications` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `user_notifications` VALUES (14,1,6,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(15,2,6,1,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(16,3,6,1,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(17,4,6,1,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(18,5,6,1,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(19,1,7,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(20,2,7,1,0,'2025-09-15 11:37:47','2025-09-14 14:26:10','2025-09-15 11:37:47'),(21,3,7,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(22,4,7,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(23,5,7,1,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(24,1,8,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10'),(25,2,9,1,0,'2025-09-15 11:37:44','2025-09-14 14:26:10','2025-09-15 11:37:44'),(26,1,10,0,0,NULL,'2025-09-14 14:26:10','2025-09-14 14:26:10');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` int DEFAULT NULL COMMENT '0:未知,1:男,2:女',
  `birth_date` date DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_seller` tinyint(1) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT NULL,
  `credit_score` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1:正常,2:冻结,3:禁用',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_admin` tinyint(1) DEFAULT '0',
  `bio` text COLLATE utf8mb4_unicode_ci COMMENT '个人简介',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_username` (`username`),
  UNIQUE KEY `ix_users_phone` (`phone`),
  KEY `ix_users_id` (`id`),
  KEY `ix_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `users` VALUES (1,'13800138001','13800138001',NULL,'$2b$12$Le/hpyZmRy.aiPwbZagp8.kwWDRmkxHJqe8J/gT.E99f7wD6R99b.',NULL,'手机用户',NULL,0,NULL,NULL,0,0,10000.00,100,1,'2025-09-13 13:21:43','2025-09-13 09:56:16','2025-09-13 21:23:16',0,NULL),(2,'18663764585','18663764585',NULL,'$2b$12$4fm/jEtx9PYTBamP6V4Yk.FtwPLbFGBbWTMmbRu3xAMiuzWTlEFRG',NULL,'用户4585',NULL,0,NULL,NULL,0,0,9999699.00,100,1,'2025-09-28 11:14:51','2025-09-13 14:37:29','2025-09-28 19:14:51',0,NULL),(3,'mingmaoguan','18888888883',NULL,'demo_hash_123456',NULL,'名猫馆',NULL,0,NULL,NULL,0,0,12000.00,100,1,NULL,'2025-09-14 09:11:53','2025-09-14 09:11:52',0,NULL),(4,'mengchongjidi','18888888884',NULL,'demo_hash_123456',NULL,'萌宠基地',NULL,0,NULL,NULL,0,0,6000.00,100,1,NULL,'2025-09-14 09:11:53','2025-09-14 09:11:52',0,NULL),(5,'baixuegongzhu','18888888885',NULL,'demo_hash_123456',NULL,'白雪公主',NULL,0,NULL,NULL,0,0,9000.00,100,1,NULL,'2025-09-14 09:11:53','2025-09-14 09:11:52',0,NULL),(6,'admin','13800138000','admin@petauction.com','$2b$12$Mmjd.6hoKuu9AH8zU2J4hexL0/8MH8vIxwMASO2JKhTo4TWtmnGT2',NULL,'管理员','系统管理员',0,NULL,NULL,0,1,0.00,100,1,NULL,'2025-09-14 12:35:18','2025-09-19 15:15:12',1,NULL),(9,'18366175208','18366175208',NULL,'$2b$12$Cf2Luk.fz671AEEMhh1DUOqqynodGON/f1QbiZv5gfYuEd44.cmuW',NULL,'用户5208',NULL,0,NULL,NULL,0,0,999999.00,100,1,'2025-09-28 15:23:30','2025-09-14 13:58:21','2025-09-28 23:23:29',0,NULL),(10,'18315707060','18315707060',NULL,'$2b$12$ce3u7LiSShaqUwWr7thOAuzQFDfwEP9Dy3d2lb4ADRMNSjgO8E8iy',NULL,'用户7060',NULL,0,NULL,NULL,0,0,9999999.00,100,1,'2025-09-28 15:18:02','2025-09-14 18:31:41','2025-09-28 23:18:02',0,NULL),(11,'18133912602','18133912602',NULL,'$2b$12$W4xRR4vdYSOoE3UYiA3tleNNM/.jlvqj4wHQjkrVzomsSeOYZAERy',NULL,'用户2602',NULL,0,NULL,NULL,0,0,0.00,100,1,'2025-09-15 04:05:19','2025-09-15 12:05:19','2025-09-15 12:05:19',0,NULL),(12,'19515866951','19515866951','','$2b$12$5Fqor3xVMVbAnNZNrcNOiOreIZshud1BTRh297wsr9mA.FGN.qflO',NULL,'用户6951','',0,NULL,'',0,0,9999.00,100,1,'2025-09-19 09:29:03','2025-09-19 17:29:02','2025-09-19 18:03:51',0,NULL),(13,'testseller','13800000001',NULL,'test_hash',NULL,NULL,NULL,0,NULL,NULL,1,0,0.00,100,1,NULL,'2025-09-19 17:49:51','2025-09-19 17:49:51',0,NULL),(14,'18888888888','18888888888',NULL,'$2b$12$KNqaIf.XxOARfZeae6QDS.DSdAzSvl7JbiBDx1ALpDmMSV91FeSUC',NULL,'测试用户',NULL,0,NULL,NULL,1,1,0.00,100,1,'2025-09-28 12:08:07','2025-09-27 13:48:15','2025-09-28 20:08:07',0,NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance_after` decimal(10,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_wallet_transactions_order_id` (`order_id`),
  KEY `ix_wallet_transactions_user_id` (`user_id`),
  KEY `ix_wallet_transactions_id` (`id`),
  CONSTRAINT `wallet_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `wallet_transactions` VALUES (1,2,'recharge',10.00,0.00,'充值失败: AlipayService.create_payment() got an unexpected keyword argument \'out_trade_no\'','failed','RECHARGE_938E2DC7B6A04886',NULL,'2025-09-13 16:39:48',NULL),(2,2,'recharge',10.00,0.00,'充值失败: AlipayService.create_payment() got an unexpected keyword argument \'out_trade_no\'','failed','RECHARGE_06A61535AC7A4606',NULL,'2025-09-13 16:40:37',NULL),(3,2,'recharge',10.00,0.00,'充值失败: AlipayService.create_payment() got an unexpected keyword argument \'out_trade_no\'','failed','RECHARGE_B5186FB2262B490D',NULL,'2025-09-13 16:44:57',NULL),(4,2,'recharge',10.00,0.00,'充值失败: AlipayService.create_payment() got an unexpected keyword argument \'out_trade_no\'','failed','RECHARGE_93F97C1AC80248BF',NULL,'2025-09-13 16:45:14',NULL),(5,2,'recharge',10.00,0.00,'钱包充值 10.0元','pending','RECHARGE_DCF3426B07984B3A',NULL,'2025-09-13 16:47:19',NULL),(6,2,'recharge',0.10,1.10,'钱包充值 0.1元','completed','RECHARGE_BB0E2FD3A92148C9',NULL,'2025-09-13 16:47:39','2025-09-14 01:01:05'),(7,2,'recharge',1.00,1.00,'钱包充值 1.0元','completed','RECHARGE_9E7CE7B4AABB45B0',NULL,'2025-09-13 16:50:59','2025-09-14 00:51:08'),(8,2,'consumption',300.00,9999699.00,'缴纳保证金 300.0元','completed',NULL,NULL,'2025-09-14 03:46:32',NULL),(9,2,'recharge',50.00,0.00,'钱包充值 50.0元','pending','RECHARGE_B64C1D8EE81049DE',NULL,'2025-09-14 10:23:58',NULL);

-- Restore settings
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
