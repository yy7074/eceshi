#!/bin/bash
# 在服务器上创建专场活动数据

echo "🚀 连接服务器创建专场活动..."

ssh root@39.96.177.57 << 'ENDSSH'
cd /www/wwwroot/backend

python3 << 'PYTHON'
import pymysql
from datetime import datetime, timedelta

try:
    print("🎯 连接数据库...")
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='123456',
        database='petshop_auction',
        charset='utf8mb4'
    )
    cursor = conn.cursor()
    
    print("✅ 连接成功！")
    print("🗑️  清除旧专场数据...")
    
    cursor.execute("DELETE FROM event_products")
    cursor.execute("DELETE FROM special_events")
    conn.commit()
    
    print("📦 创建新专场活动...")
    now = datetime.now()
    
    events = [
        (1, '新春萌宠专场', '新春特惠，精选优质宠物，限时拍卖！', '/static/uploads/event1.jpg', 
         now - timedelta(days=1), now + timedelta(days=30), 1, now),
        (2, '水族精品专场', '精品观赏鱼和水族用品，打造完美水族世界', '/static/uploads/event2.jpg',
         now - timedelta(hours=12), now + timedelta(days=25), 1, now),
        (3, '一口价精选', '精选优质商品，一口价直接购买，无需等待', '/static/uploads/event3.jpg',
         now - timedelta(days=2), now + timedelta(days=60), 1, now),
        (4, '爬宠专区', '各类爬行宠物及用品专场', '/static/uploads/event4.jpg',
         now, now + timedelta(days=15), 1, now),
    ]
    
    for event in events:
        cursor.execute("""
            INSERT INTO special_events 
            (id, title, description, banner_image, start_time, end_time, is_active, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, event)
        print(f"  ✅ {event[1]}")
    
    conn.commit()
    
    cursor.execute("SELECT COUNT(*) FROM special_events")
    count = cursor.fetchone()[0]
    print(f"\n🎉 成功创建 {count} 个专场活动！")
    
    cursor.execute("""
        SELECT id, title, 
               DATE_FORMAT(start_time, '%Y-%m-%d %H:%i') as start_time,
               DATE_FORMAT(end_time, '%Y-%m-%d %H:%i') as end_time,
               is_active 
        FROM special_events ORDER BY id
    """)
    
    print("\n📋 专场活动列表:")
    print("-" * 80)
    for row in cursor.fetchall():
        status = "🟢 进行中" if row[4] else "🔴 已结束"
        print(f"ID: {row[0]} | {row[1]}")
        print(f"   时间: {row[2]} ~ {row[3]} | {status}")
        print("-" * 80)
    
    cursor.close()
    conn.close()
    print("\n✅ 所有操作完成！")
    
except Exception as e:
    print(f"❌ 错误: {e}")
    import traceback
    traceback.print_exc()

PYTHON

# 重启Python应用
echo ""
echo "🔄 重启Python应用..."
supervisorctl restart petshop_backend 2>/dev/null || echo "请在宝塔面板手动重启应用"

ENDSSH

echo ""
echo "🎯 验证专场活动API..."
sleep 2
curl -s "http://39.96.177.57:3000/api/v1/events/" | python3 -m json.tool | head -50

