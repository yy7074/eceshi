from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional
from decimal import Decimal
import time

from ..core.database import get_db
from ..core.security import get_current_user
from ..models.user import User
from ..models.order import Order, Payment
from ..schemas.order import (
    OrderCreate, OrderResponse, OrderListResponse, OrderUpdate,
    PaymentCreate, PaymentResponse, LogisticsResponse
)
from ..services.order_service import OrderService
from ..services.payment_service import PaymentService
from ..services.logistics_service import LogisticsService
from ..services.alipay_service import AlipayService
from ..services.test_payment_service import TestPaymentService

router = APIRouter()
order_service = OrderService()
payment_service = PaymentService()
logistics_service = LogisticsService()
alipay_service = AlipayService()
test_payment_service = TestPaymentService()

@router.post("/", response_model=OrderResponse)
async def create_order(
    order_data: OrderCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建订单"""
    try:
        order = await order_service.create_order(db, order_data, current_user.id)
        
        # 后台任务：发送订单通知
        background_tasks.add_task(
            order_service.send_order_notification,
            db, order.id, "created"
        )
        
        return order
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="创建订单失败")

@router.get("/", response_model=OrderListResponse)
async def get_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[str] = Query(None, regex="^(pending|paid|shipped|delivered|completed|cancelled|refunded)$"),
    order_type: Optional[str] = Query(None, regex="^(buy|sell)$"),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取订单列表"""
    return await order_service.get_user_orders(
        db, current_user.id, page, page_size, status, order_type, start_date, end_date
    )

@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取订单详情"""
    order = await order_service.get_order_detail(db, order_id, current_user.id)
    if not order:
        raise HTTPException(status_code=404, detail="订单不存在")
    return order

@router.put("/{order_id}", response_model=OrderResponse)
async def update_order(
    order_id: int,
    order_data: OrderUpdate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新订单"""
    try:
        order = await order_service.update_order(db, order_id, order_data, current_user.id)
        if not order:
            raise HTTPException(status_code=404, detail="订单不存在或无权限修改")
        
        # 后台任务：发送状态变更通知
        if order_data.status:
            background_tasks.add_task(
                order_service.send_order_notification,
                db, order_id, order_data.status
            )
        
        return order
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/{order_id}/status")
async def update_order_status(
    order_id: int,
    status: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新订单状态"""
    try:
        success = await order_service.update_order_status(db, order_id, status, current_user.id)
        if not success:
            raise HTTPException(status_code=404, detail="订单不存在或无权限修改")
        
        # 后台任务：发送状态变更通知
        background_tasks.add_task(
            order_service.send_order_notification,
            db, order_id, status
        )
        
        return {"message": "订单状态更新成功"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/{order_id}/cancel")
async def cancel_order(
    order_id: int,
    background_tasks: BackgroundTasks,
    reason: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """取消订单"""
    try:
        success = await order_service.cancel_order(db, order_id, current_user.id, reason)
        if not success:
            raise HTTPException(status_code=404, detail="订单不存在或无法取消")
        
        # 后台任务：处理退款和通知
        background_tasks.add_task(
            order_service.process_order_cancellation,
            db, order_id
        )
        
        return {"message": "订单取消成功"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/{order_id}/confirm")
async def confirm_order(
    order_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """确认收货"""
    try:
        success = await order_service.confirm_order(db, order_id, current_user.id)
        if not success:
            raise HTTPException(status_code=404, detail="订单不存在或无法确认收货")
        
        # 后台任务：完成订单处理
        background_tasks.add_task(
            order_service.complete_order_process,
            db, order_id
        )
        
        return {"message": "确认收货成功"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/{order_id}/pay")
async def pay_order(
    order_id: int,
    payment_method: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """支付订单"""
    try:
        # 获取订单
        order = db.query(Order).filter(
            Order.id == order_id,
            Order.buyer_id == current_user.id
        ).first()
        
        if not order:
            raise HTTPException(status_code=404, detail="订单不存在")
            
        if order.order_status != 1:  # 只有待支付状态才能支付
            raise HTTPException(status_code=400, detail="订单状态不允许支付")
        
        # 这里可以集成真实的支付接口
        # 目前返回模拟支付结果
        return {
            "success": True,
            "message": "支付处理中",
            "payment_url": f"/pay/{order_id}?method={payment_method}"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="支付处理失败")

@router.post("/{order_id}/apply-refund")
async def apply_refund(
    order_id: int,
    reason: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """申请退款"""
    try:
        order = db.query(Order).filter(
            Order.id == order_id,
            Order.buyer_id == current_user.id
        ).first()
        
        if not order:
            raise HTTPException(status_code=404, detail="订单不存在")
            
        if order.payment_status != 2:  # 只有已支付的订单才能申请退款
            raise HTTPException(status_code=400, detail="订单状态不允许申请退款")
        
        # 创建退款申请记录
        # 这里可以添加退款申请的逻辑
        
        return {"message": "退款申请已提交，请等待处理"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="申请退款失败")

@router.post("/{order_id}/confirm-received")
async def confirm_received(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """确认收货"""
    try:
        order = db.query(Order).filter(
            Order.id == order_id,
            Order.buyer_id == current_user.id
        ).first()
        
        if not order:
            raise HTTPException(status_code=404, detail="订单不存在")
            
        if order.order_status != 3:  # 只有已发货状态才能确认收货
            raise HTTPException(status_code=400, detail="订单状态不允许确认收货")
        
        # 更新订单状态
        order.order_status = 4  # 已收货
        order.received_at = datetime.now()
        db.commit()
        
        return {"message": "确认收货成功"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="确认收货失败")

# 支付相关接口
@router.post("/payments/", response_model=PaymentResponse)
async def create_payment(
    payment_data: PaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建支付"""
    try:
        payment = await payment_service.create_payment(db, payment_data, current_user.id)
        return payment
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="创建支付失败")

@router.get("/payments/{payment_id}", response_model=PaymentResponse)
async def get_payment(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取支付详情"""
    payment = await payment_service.get_payment_detail(db, payment_id, current_user.id)
    if not payment:
        raise HTTPException(status_code=404, detail="支付记录不存在")
    return payment

@router.post("/payments/{payment_id}/notify")
async def payment_notify(
    payment_id: int,
    notify_data: dict,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """支付回调通知"""
    try:
        success = await payment_service.handle_payment_notify(db, payment_id, notify_data)
        if success:
            # 后台任务：处理支付成功后续流程
            background_tasks.add_task(
                payment_service.process_payment_success,
                db, payment_id
            )
        return {"message": "通知处理成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail="处理支付通知失败")

# 物流相关接口
@router.get("/{order_id}/logistics", response_model=LogisticsResponse)
async def get_order_logistics(
    order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取订单物流信息"""
    logistics = await logistics_service.get_order_logistics(db, order_id, current_user.id)
    if not logistics:
        raise HTTPException(status_code=404, detail="物流信息不存在")
    return logistics

@router.put("/{order_id}/logistics")
async def update_logistics(
    order_id: int,
    tracking_number: str,
    logistics_company: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新物流信息（卖家操作）"""
    try:
        success = await logistics_service.update_logistics(
            db, order_id, tracking_number, logistics_company, current_user.id
        )
        if not success:
            raise HTTPException(status_code=404, detail="订单不存在或无权限修改")
        
        # 后台任务：发送发货通知
        background_tasks.add_task(
            logistics_service.send_shipping_notification,
            db, order_id
        )
        
        return {"message": "物流信息更新成功"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/statistics")
async def get_order_statistics(
    period: str = Query("month", regex="^(week|month|quarter|year)$"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取订单统计信息"""
    return await order_service.get_user_order_statistics(db, current_user.id, period)

# 支付宝支付接口
@router.post("/test/create")
async def create_test_order(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建测试订单"""
    try:
        # 创建测试订单
        order = Order(
            order_no=f"TEST_{int(time.time())}",
            buyer_id=current_user.id,
            seller_id=1,  # 测试卖家
            product_id=1,  # 测试商品
            final_price=0.01,  # 测试金额
            total_amount=0.01,
            shipping_fee=0.00,
            payment_method=1,  # 1:支付宝
            payment_status=1,  # 1:待支付
            order_status=1,  # 1:待支付
        )
        
        db.add(order)
        db.commit()
        db.refresh(order)
        
        # 创建订单项
        from ..models.order import OrderItem
        order_item = OrderItem(
            order_id=order.id,
            product_id=1,
            product_title="测试商品",
            product_image="https://picsum.photos/200/200?random=1",
            quantity=1,
            unit_price=0.01,
            total_price=0.01
        )
        
        db.add(order_item)
        db.commit()
        
        return {
            "success": True,
            "data": {
                "order_id": order.id,
                "order_no": order.order_no,
                "total_amount": str(order.total_amount)
            }
        }
    except Exception as e:
        print(f"创建测试订单失败: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"创建测试订单失败: {str(e)}")

@router.post("/test/create-multiple")
async def create_multiple_test_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建多个不同状态的测试订单"""
    try:
        from ..models.order import OrderItem
        import uuid
        from datetime import datetime
        
        # 订单状态配置
        order_configs = [
            (1, "待付款", 1, "待支付"),
            (2, "待发货", 2, "已支付"),
            (3, "待收货", 2, "已发货"),
            (4, "已完成", 2, "已收货"),
            (6, "已取消", 3, "已取消"),
        ]
        
        created_orders = []
        
        for i, (order_status, status_desc, payment_status, payment_desc) in enumerate(order_configs, 1):
            # 创建测试订单
            order = Order(
                order_no=f"PET{datetime.now().strftime('%Y%m%d%H%M%S')}{str(uuid.uuid4().int)[:4]}{i}",
                buyer_id=current_user.id,
                seller_id=1,  # 测试卖家
                product_id=i,  # 不同的测试商品ID
                final_price=Decimal('99.99') + i * 10,
                total_amount=Decimal('109.99') + i * 10,
                shipping_fee=Decimal('10.00'),
                payment_method=1,  # 1:支付宝
                payment_status=payment_status,
                order_status=order_status,
            )
            
            db.add(order)
            db.flush()  # 获取order.id
            
            # 创建订单项
            order_item = OrderItem(
                order_id=order.id,
                product_id=i,
                product_title=f"测试商品{i} - {status_desc}",
                product_image=f"https://picsum.photos/200/200?random={i}",
                quantity=1,
                unit_price=Decimal('99.99') + i * 10,
                total_price=Decimal('99.99') + i * 10
            )
            
            db.add(order_item)
            
            created_orders.append({
                "order_no": order.order_no,
                "status": status_desc,
                "payment_status": payment_desc,
                "total_amount": str(order.total_amount)
            })
        
        db.commit()
        
        return {
            "success": True,
            "message": f"成功创建{len(order_configs)}个测试订单",
            "data": created_orders
        }
    except Exception as e:
        db.rollback()
        print(f"创建测试订单失败: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"创建测试订单失败: {str(e)}")

@router.post("/{order_id}/alipay/app")
async def create_alipay_app_payment(
    order_id: int,
    notify_url: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建支付宝App支付"""
    try:
        # 使用真实支付宝服务
        payment_data = await alipay_service.create_payment(
            db, order_id, current_user.id, notify_url=notify_url
        )
        return {
            "success": True,
            "data": payment_data
        }
    except ValueError as e:
        print(f"支付宝支付ValueError: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        print(f"支付宝支付Exception: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"创建支付失败: {str(e)}")

@router.get("/payments/{payment_id}/alipay/query")
async def query_alipay_payment(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """查询支付宝支付状态"""
    try:
        # 使用测试支付服务查询
        payment = db.query(Payment).filter(Payment.id == payment_id).first()
        if not payment:
            raise HTTPException(status_code=404, detail="支付记录不存在")
            
        if payment.user_id != current_user.id:
            raise HTTPException(status_code=403, detail="无权限查询此支付记录")
            
        # 模拟查询结果
        result = await test_payment_service.query_payment(payment.transaction_id)
        
        return {
            "success": True,
            "data": result
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"查询支付状态失败: {e}")
        raise HTTPException(status_code=500, detail=f"查询支付状态失败: {str(e)}")

# 创建测试订单接口
@router.post("/test/create-sample")
async def create_sample_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建示例订单数据"""
    try:
        from ..models.order import Order, OrderItem
        from datetime import datetime, timedelta
        import uuid
        
        sample_orders = []
        
        # 创建不同状态的测试订单
        order_statuses = [
            (1, "待支付", 1),
            (2, "待发货", 2), 
            (3, "已发货", 2),
            (4, "已收货", 2),
            (5, "已完成", 2),
        ]
        
        for i, (order_status, desc, payment_status) in enumerate(order_statuses, 1):
            # 创建测试订单
            test_order = Order(
                order_no=f"PET{datetime.now().strftime('%Y%m%d%H%M%S')}{str(uuid.uuid4().int)[:4]}{i}",
                buyer_id=current_user.id,
                seller_id=1,  # 假设存在卖家ID 1
                product_id=i,  # 假设存在商品ID
                final_price=99.99 + i * 10,
                shipping_fee=10.00,
                total_amount=109.99 + i * 10,
                order_status=order_status,
                payment_status=payment_status,
                payment_method=1,  # 支付宝
                shipping_address={
                    "name": "测试用户", 
                    "phone": "13800138000", 
                    "address": f"测试地址{i}号",
                    "province": "广东省",
                    "city": "深圳市",
                    "district": "南山区"
                },
                tracking_number=f"SF{datetime.now().strftime('%Y%m%d')}{1000+i}" if order_status >= 3 else None,
                shipped_at=datetime.now() - timedelta(days=2) if order_status >= 3 else None,
                received_at=datetime.now() - timedelta(days=1) if order_status >= 4 else None,
                completed_at=datetime.now() if order_status == 5 else None
            )
            
            db.add(test_order)
            db.commit()
            db.refresh(test_order)
            
            # 创建订单项
            order_item = OrderItem(
                order_id=test_order.id,
                product_id=i,
                product_title=f"测试商品{i} - {desc}",
                product_image=f"https://picsum.photos/200/200?random={i}",
                quantity=1,
                unit_price=test_order.final_price,
                total_price=test_order.final_price
            )
            
            db.add(order_item)
            db.commit()
            
            sample_orders.append({
                "order_id": test_order.id,
                "order_no": test_order.order_no,
                "status": desc,
                "total_amount": float(test_order.total_amount)
            })
        
        return {
            "success": True,
            "message": "示例订单创建成功",
            "data": sample_orders
        }
    except Exception as e:
        print(f"创建示例订单失败: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"创建示例订单失败: {str(e)}")

@router.post("/{order_id}/alipay/web")
async def create_alipay_web_payment(
    order_id: int,
    return_url: Optional[str] = None,
    notify_url: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建支付宝网页支付"""
    try:
        payment_url = await alipay_service.create_web_payment(
            db, order_id, current_user.id, return_url, notify_url
        )
        return {
            "success": True,
            "payment_url": payment_url
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="创建支付失败")

@router.post("/payments/{payment_id}/alipay/notify")
async def alipay_notify(
    payment_id: int,
    notify_data: dict,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """支付宝支付回调通知"""
    try:
        success = await alipay_service.handle_notify(db, payment_id, notify_data)
        if success:
            return "success"
        else:
            return "fail"
    except Exception as e:
        print(f"处理支付宝通知失败: {e}")
        return "fail"

@router.get("/payments/{payment_id}/alipay/query")
async def query_alipay_payment(
    payment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """查询支付宝支付状态"""
    try:
        # 获取支付记录
        payment = db.query(Payment).filter(
            Payment.id == payment_id,
            Payment.user_id == current_user.id
        ).first()
        
        if not payment:
            raise HTTPException(status_code=404, detail="支付记录不存在")
            
        # 查询支付状态
        result = await alipay_service.query_payment(payment.transaction_id)
        return {
            "success": True,
            "data": result
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="查询支付状态失败")

@router.post("/payments/{payment_id}/alipay/refund")
async def create_alipay_refund(
    payment_id: int,
    refund_amount: Optional[float] = None,
    refund_reason: str = "用户申请退款",
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """申请支付宝退款"""
    try:
        # 验证权限
        payment = db.query(Payment).filter(
            Payment.id == payment_id,
            Payment.user_id == current_user.id
        ).first()
        
        if not payment:
            raise HTTPException(status_code=404, detail="支付记录不存在")
            
        result = await alipay_service.refund(
            db, payment_id, 
            Decimal(str(refund_amount)) if refund_amount else None, 
            refund_reason
        )
        return result
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="申请退款失败")